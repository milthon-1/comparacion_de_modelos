# -*- coding: utf-8 -*-
"""
=============================================================================
 ANÁLISIS COMPLETO: EDA + COMPARACIÓN DE MODELOS CON LAZYPREDICT
 Dataset: turismo_puno_2019_2024.csv  |  Objetivo: gasto_promedio_soles
 Autor:   Milton Flores Flores (231210) - FINESI UNAP
=============================================================================
Genera:
  - resultados_lazypredict/Resultados_LazyPredict_Turismo_Puno.xlsx
      (una hoja por tabla + hoja "Graficos" con todas las figuras)
  - resultados_lazypredict/figuras/*.png   (todos los gráficos)

Requisitos (una sola vez):
  pip install pandas numpy scipy matplotlib scikit-learn lazypredict lightgbm xgboost openpyxl pillow

Tiempo aproximado: 2 a 4 minutos (la parte más lenta son las 10 semillas).
=============================================================================
"""
import os
import time
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")                     # guarda los gráficos sin abrir ventanas
import matplotlib.pyplot as plt
from scipy import stats

from lazypredict.Supervised import LazyRegressor
from sklearn.model_selection import (train_test_split, RepeatedKFold, cross_validate,
                                     GridSearchCV, KFold)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.linear_model import LinearRegression, Ridge, LassoCV, OrthogonalMatchingPursuitCV
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.dummy import DummyRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.inspection import permutation_importance
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor

warnings.filterwarnings("ignore")

# =============================================================================
# 0. CONFIGURACIÓN
# =============================================================================
RUTA_PC = r"C:\Users\lenovo\Downloads\archive (2)\turismo_puno_2019_2024.csv"
CARPETA_SCRIPT = os.path.dirname(os.path.abspath(__file__))
RUTA = RUTA_PC if os.path.exists(RUTA_PC) else os.path.join(CARPETA_SCRIPT, "turismo_puno_2019_2024.csv")

SALIDA = os.path.join(CARPETA_SCRIPT, "resultados_lazypredict")
FIG = os.path.join(SALIDA, "figuras")
EXCEL = os.path.join(SALIDA, "Resultados_LazyPredict_Turismo_Puno.xlsx")
os.makedirs(FIG, exist_ok=True)

OBJ = "gasto_promedio_soles"
SEMILLA = 42
N_SEMILLAS = 10            # particiones para el análisis de estabilidad (E3)

# Estilo de gráficos
PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
AZUL, NAVY, GRIS = PAL[0], "#1f2a44", "#8a8986"
plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 160, "font.size": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "axes.axisbelow": True, "grid.color": "#e6e5e1", "grid.linewidth": 0.6,
    "axes.edgecolor": "#b9b8b3", "axes.titleweight": "bold", "axes.titlesize": 11,
    "axes.titlecolor": NAVY, "legend.frameon": False,
})

TABLAS = {}      # nombre de hoja -> DataFrame (se exportan al Excel al final)
FIGURAS = []     # (archivo, título) en orden


def guardar(nombre, titulo):
    """Guarda la figura actual en PNG y la registra para el Excel."""
    plt.tight_layout()
    ruta = os.path.join(FIG, f"{nombre}.png")
    plt.savefig(ruta, bbox_inches="tight")
    plt.close()
    FIGURAS.append((ruta, titulo))
    print(f"   [figura] {nombre}.png")


def boxh(ax, data, labels=None, **kw):
    """Boxplot horizontal compatible con versiones nuevas y antiguas de matplotlib."""
    estilo = dict(patch_artist=True, widths=.6,
                  boxprops=dict(facecolor="#cfe0f6", edgecolor=AZUL), medianprops=dict(color=NAVY, lw=2),
                  whiskerprops=dict(color=AZUL), capprops=dict(color=AZUL),
                  flierprops=dict(marker="o", markersize=2, markerfacecolor=AZUL, markeredgecolor=AZUL))
    estilo.update(kw)
    try:
        return ax.boxplot(data, orientation="horizontal", tick_labels=labels, **estilo)
    except TypeError:
        return ax.boxplot(data, vert=False, labels=labels, **estilo)


def heatmap(ax, M, titulo, cmap="RdBu_r", vmin=-1, vmax=1):
    """Mapa de calor con anotaciones (sin depender de seaborn)."""
    im = ax.imshow(M.values, cmap=cmap, vmin=vmin, vmax=vmax)
    ax.set_xticks(range(M.shape[1])); ax.set_xticklabels(M.columns, rotation=90, fontsize=8)
    ax.set_yticks(range(M.shape[0])); ax.set_yticklabels(M.index, fontsize=8)
    ax.grid(False)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = M.values[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=7,
                    color="white" if abs(v) > 0.6 * max(abs(vmin), abs(vmax)) else "#222")
    ax.set_title(titulo)
    plt.colorbar(im, ax=ax, shrink=.75)


def eta2(grupos, y):
    """Proporción de la varianza de y explicada por los grupos."""
    medias = y.groupby(grupos).transform("mean")
    return 1 - ((y - medias) ** 2).sum() / ((y - y.mean()) ** 2).sum()


def cramer_v(a, b):
    tabla = pd.crosstab(a, b)
    chi2 = stats.chi2_contingency(tabla, correction=False)[0]
    n = tabla.values.sum(); r, k = tabla.shape
    return np.sqrt(chi2 / (n * (min(r, k) - 1)))


def lazy(Xtr, Xte, ytr, yte):
    """Ejecuta LazyRegressor y devuelve la tabla de modelos."""
    reg = LazyRegressor(verbose=0, ignore_warnings=True, custom_metric=None)
    modelos, _ = reg.fit(Xtr, Xte, ytr, yte)
    return modelos


T0 = time.time()
print("=" * 70)
print(" ANÁLISIS EDA + LAZYPREDICT - Turismo Puno 2019-2024")
print("=" * 70)

# =============================================================================
# 1. CARGA Y ESTRUCTURA
# =============================================================================
print("\n[1] Carga y estructura del dataset")
df = pd.read_csv(RUTA)
print(f"   Archivo: {RUTA}\n   Dimensiones: {df.shape}")

diccionario = pd.DataFrame({
    "variable": df.columns,
    "tipo": df.dtypes.astype(str).values,
    "valores_unicos": df.nunique().values,
    "nulos": df.isna().sum().values,
    "ejemplo": df.iloc[0].astype(str).values,
})
diccionario["rol"] = "predictor"
diccionario.loc[diccionario.variable == "id", "rol"] = "identificador (se excluye)"
diccionario.loc[diccionario.variable == "mes", "rol"] = "redundante con mes_num (se excluye)"
diccionario.loc[diccionario.variable == OBJ, "rol"] = "VARIABLE OBJETIVO"
TABLAS["01_Diccionario"] = diccionario

# =============================================================================
# 2. CALIDAD DE DATOS
# =============================================================================
print("\n[2] Calidad de los datos")
calidad = pd.DataFrame({
    "indicador": ["Registros", "Variables", "Valores nulos (total)", "Filas duplicadas (sin id)",
                  "Años", "Meses en 2024", "Combinaciones año-mes-sitio-nacionalidad únicas",
                  "¿Clima igual para todos los sitios en un mismo mes?"],
    "valor": [len(df), df.shape[1], int(df.isna().sum().sum()), int(df.drop(columns="id").duplicated().sum()),
              f"{df.anio.min()}-{df.anio.max()}", df.query("anio == 2024").mes_num.nunique(),
              df.groupby(["anio", "mes_num", "sitio_turistico", "nacionalidad"]).ngroups,
              "Sí" if (df.groupby(["anio", "mes_num"])[["temperatura_promedio_c", "precipitacion_mm"]]
                       .nunique() == 1).all().all() else "No"],
})
TABLAS["02_Calidad"] = calidad
TABLAS["03_Registros_por_anio"] = df.anio.value_counts().sort_index().rename_axis("anio").reset_index(name="registros")
print(calidad.to_string(index=False))

# =============================================================================
# 3. ANÁLISIS UNIVARIADO
# =============================================================================
print("\n[3] Análisis univariado")
y = df[OBJ]
num = ["num_visitantes", "temperatura_promedio_c", "precipitacion_mm", "satisfaccion_1_5"]
cat = ["sitio_turistico", "nacionalidad", "temporada", "festividad", "tipo_transporte"]

desc = df[num + [OBJ]].describe().T
desc["CV_%"] = 100 * desc["std"] / desc["mean"]
desc["asimetria"] = df[num + [OBJ]].skew()
desc["curtosis"] = df[num + [OBJ]].kurt()
TABLAS["04_Descriptivos"] = desc.reset_index().rename(columns={"index": "variable"})

sw = stats.shapiro(y)
TABLAS["05_Normalidad_objetivo"] = pd.DataFrame({
    "prueba": ["Shapiro-Wilk"], "estadistico": [sw.statistic], "p_valor": [sw.pvalue],
    "conclusion": ["No normal" if sw.pvalue < .05 else "Normal"]})

frec = []
for c in cat:
    vc = df[c].value_counts()
    frec.append(pd.DataFrame({"variable": c, "categoria": vc.index, "frecuencia": vc.values,
                              "porcentaje": (100 * vc / len(df)).round(2).values}))
TABLAS["06_Frecuencias"] = pd.concat(frec, ignore_index=True)

fig, ax = plt.subplots(1, 3, figsize=(13, 3.6))
ax[0].hist(y, bins=40, color=AZUL, edgecolor="white")
ax[0].axvline(y.mean(), color=NAVY, ls="--", lw=1.5, label=f"media = {y.mean():.1f}")
ax[0].set(title="Distribución del gasto promedio", xlabel="soles", ylabel="frecuencia"); ax[0].legend()
boxh(ax[1], [y.values], widths=.5)
ax[1].set(title="Diagrama de caja", xlabel="soles", yticks=[])
stats.probplot(y, dist="norm", plot=ax[2])
ax[2].get_lines()[0].set(markerfacecolor=AZUL, markeredgecolor=AZUL, markersize=3)
ax[2].get_lines()[1].set(color=NAVY); ax[2].set_title("Gráfico Q-Q normal")
guardar("01_objetivo", "Distribución de la variable objetivo")

fig, ax = plt.subplots(1, 4, figsize=(14, 3.2))
for a, c in zip(ax, num):
    a.hist(df[c], bins=30, color=AZUL, edgecolor="white"); a.set(title=c, ylabel="frecuencia")
guardar("02_numericas", "Distribución de predictores numéricos")

fig, ax = plt.subplots(1, 5, figsize=(17, 3.6))
for a, c in zip(ax, cat):
    vc = df[c].value_counts()
    a.barh(vc.index[::-1], vc.values[::-1], color=AZUL, height=.6); a.set(title=c, xlabel="registros")
guardar("03_categoricas", "Frecuencia de predictores categóricos")

# =============================================================================
# 4. ANÁLISIS BIVARIADO CON EL GASTO
# =============================================================================
print("\n[4] Análisis bivariado")
filas = []
for c in cat + ["anio", "mes_num", "tiene_festividad"]:
    grupos = [v[OBJ].values for _, v in df.groupby(c)]
    F = stats.f_oneway(*grupos); K = stats.kruskal(*grupos)
    filas.append([c, df[c].nunique(), F.statistic, F.pvalue, K.statistic, K.pvalue, eta2(df[c], y)])
pruebas = (pd.DataFrame(filas, columns=["variable", "niveles", "F_ANOVA", "p_ANOVA", "H_Kruskal",
                                        "p_Kruskal", "eta2"])
           .sort_values("eta2", ascending=False).reset_index(drop=True))
TABLAS["07_Pruebas_bivariadas"] = pruebas
print(pruebas.round(4).to_string(index=False))

medias = []
for c in cat:
    g = df.groupby(c)[OBJ].agg(["count", "mean", "std", "median", "min", "max"]).reset_index()
    g.insert(0, "variable", c); g = g.rename(columns={c: "categoria"})
    medias.append(g)
TABLAS["08_Gasto_por_categoria"] = pd.concat(medias, ignore_index=True)

fig, ax = plt.subplots(2, 3, figsize=(15, 8))
for a, c in zip(ax.flat, ["nacionalidad", "sitio_turistico", "tipo_transporte", "temporada", "festividad", "anio"]):
    orden = df.groupby(c)[OBJ].median().sort_values().index
    boxh(a, [df.loc[df[c] == k, OBJ].values for k in orden], [str(k) for k in orden])
    e = pruebas.set_index("variable").loc[c, "eta2"]
    a.set(title=f"Gasto según {c}  (eta² = {e:.3f})", xlabel="gasto promedio (S/)")
guardar("04_boxplots_categoricas", "Gasto según variables categóricas")

cols_num = ["anio", "mes_num", "tiene_festividad"] + num + [OBJ]
pear = df[cols_num].corr(); spear = df[cols_num].corr(method="spearman")
TABLAS["09_Correlacion_Pearson"] = pear.round(4).reset_index().rename(columns={"index": "variable"})
TABLAS["10_Correlacion_Spearman"] = spear.round(4).reset_index().rename(columns={"index": "variable"})
fig, ax = plt.subplots(1, 2, figsize=(15, 6))
heatmap(ax[0], pear, "Correlación de Pearson"); heatmap(ax[1], spear, "Correlación de Spearman")
guardar("05_correlaciones", "Matrices de correlación")

nac_orden = df.groupby("nacionalidad")[OBJ].mean().sort_values(ascending=False).index
fig, ax = plt.subplots(1, 2, figsize=(13, 4.2))
for i, n in enumerate(nac_orden):
    d = df[df.nacionalidad == n]
    ax[0].scatter(d.num_visitantes, d[OBJ], s=9, alpha=.55, color=PAL[i], label=n)
ax[0].set(xscale="log", title="Gasto vs. visitantes (escala log)", xlabel="visitantes", ylabel="gasto (S/)")
ax[0].legend(fontsize=8, ncol=2, markerscale=1.6)
vis = df.groupby("nacionalidad")["num_visitantes"].mean().reindex(nac_orden)
ax[1].bar(vis.index, vis.values, color=AZUL, width=.6)
ax[1].set(title="Visitantes promedio por nacionalidad", ylabel="visitantes"); ax[1].tick_params(axis="x", rotation=25)
guardar("06_visitantes", "Gasto vs. visitantes por nacionalidad")
TABLAS["11_Corr_visit_gasto_por_nac"] = (df.groupby("nacionalidad")
    .apply(lambda d: d["num_visitantes"].corr(d[OBJ])).rename("r_visitantes_gasto").reset_index())

# =============================================================================
# 5. REDUNDANCIAS, SERIE TEMPORAL, HETEROCEDASTICIDAD Y ATÍPICOS
# =============================================================================
print("\n[5] Redundancias, evolución temporal y atípicos")
vars_cat = ["mes_num", "temporada", "festividad", "tiene_festividad", "sitio_turistico", "tipo_transporte", "nacionalidad"]
V = pd.DataFrame([[cramer_v(df[a], df[b]) for b in vars_cat] for a in vars_cat], index=vars_cat, columns=vars_cat)
TABLAS["12_V_de_Cramer"] = V.round(4).reset_index().rename(columns={"index": "variable"})
fig, ax = plt.subplots(figsize=(8, 6.5))
heatmap(ax, V, "V de Cramér entre variables categóricas", cmap="Blues", vmin=0, vmax=1)
guardar("07_cramer", "V de Cramér")
TABLAS["13_Sitio_vs_transporte"] = pd.crosstab(df.sitio_turistico, df.tipo_transporte).reset_index()
TABLAS["14_Calendario_mensual"] = (df.groupby("mes_num").agg(
    temporada=("temporada", "first"), festividad=("festividad", "first"),
    temp_media=("temperatura_promedio_c", "mean"), precip_media=("precipitacion_mm", "mean")).round(2).reset_index())

df["fecha"] = pd.to_datetime(dict(year=df.anio, month=df.mes_num, day=1))
serie = df.groupby(["fecha", "nacionalidad"])[OBJ].mean().unstack()[nac_orden]
TABLAS["15_Serie_mensual"] = serie.round(2).reset_index()
fig, ax = plt.subplots(figsize=(13, 4.4))
for i, n in enumerate(nac_orden):
    ax.plot(serie.index, serie[n], lw=2, color=PAL[i], label=n)
ax.set(title="Gasto promedio mensual por nacionalidad", ylabel="gasto (S/)")
ax.legend(ncol=6, fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.08))
guardar("08_serie_temporal", "Gasto mensual por nacionalidad")

disp = df.groupby("nacionalidad")[OBJ].agg(media="mean", desv="std").reindex(nac_orden)
disp["CV_%"] = 100 * disp.desv / disp.media
lev = stats.levene(*[v[OBJ].values for _, v in df.groupby("nacionalidad")])
disp["Levene_W"] = lev.statistic; disp["Levene_p"] = lev.pvalue
TABLAS["16_Heterocedasticidad"] = disp.reset_index()
fig, ax = plt.subplots(figsize=(6, 4))
ax.scatter(disp.media, disp.desv, s=60, color=AZUL, zorder=3)
for n, r in disp.iterrows():
    ax.annotate(n, (r.media, r.desv), xytext=(6, -3), textcoords="offset points", fontsize=8)
ax.set(title="La desviación crece con la media", xlabel="media (S/)", ylabel="desviación (S/)")
guardar("09_heterocedasticidad", "Heterocedasticidad por nacionalidad")


def atipicos_iqr(s):
    q1, q3 = s.quantile([.25, .75]); iqr = q3 - q1
    return int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())


at = pd.DataFrame({"variable": num + [OBJ],
                   "atipicos_IQR": [atipicos_iqr(df[c]) for c in num + [OBJ]]})
at["porcentaje"] = (100 * at.atipicos_IQR / len(df)).round(2)
TABLAS["17_Atipicos"] = at

# =============================================================================
# 6. E1 - DIAGNÓSTICO DEL CÓDIGO ORIGINAL (R² ≈ 0)
# =============================================================================
print("\n[6] E1: réplica del error original (dummies bool descartadas)")
X_orig = pd.get_dummies(df.drop(columns=["id", "mes", "fecha", OBJ]), drop_first=True)
tipos = X_orig.dtypes.astype(str).value_counts().rename_axis("tipo").reset_index(name="columnas")
TABLAS["18_Tipos_get_dummies"] = tipos
print(tipos.to_string(index=False))
X_rep = X_orig.select_dtypes("number")               # lo que realmente usaba la versión original
Xtr, Xte, ytr, yte = train_test_split(X_rep, y, test_size=0.2, random_state=SEMILLA)
mod_rep = lazy(Xtr, Xte, ytr, yte)
TABLAS["19_E1_LazyPredict_original"] = mod_rep.reset_index()
print(f"   Variables usadas: {X_rep.shape[1]} | mejor R² = {mod_rep['R-Squared'].max():.4f}")

# =============================================================================
# 7. E2 - LAZYPREDICT CORREGIDO
# =============================================================================
print("\n[7] E2: LazyPredict corregido (dtype=int)")
X = pd.get_dummies(df.drop(columns=["id", "mes", "fecha", OBJ]), drop_first=True, dtype=int)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=SEMILLA)
t0 = time.time()
models = lazy(X_train, X_test, y_train, y_test)
t_lazy = time.time() - t0
print(f"   {len(models)} modelos en {t_lazy:.1f} s | {X.shape[1]} predictores")
print(models.head(10).round(4).to_string())

familia = {
 "Lineal": ["OrthogonalMatchingPursuitCV", "SGDRegressor", "LassoCV", "LassoLarsIC", "LarsCV", "LassoLarsCV",
            "LinearRegression", "TransformedTargetRegressor", "Ridge", "HuberRegressor", "BayesianRidge", "RidgeCV",
            "ElasticNetCV", "Lars", "Lasso", "LassoLars", "LinearSVR", "ElasticNet", "RANSACRegressor",
            "OrthogonalMatchingPursuit", "PassiveAggressiveRegressor", "QuantileRegressor"],
 "GLM": ["PoissonRegressor", "TweedieRegressor", "GammaRegressor"],
 "Ensamble de árboles": ["GradientBoostingRegressor", "AdaBoostRegressor", "RandomForestRegressor",
            "HistGradientBoostingRegressor", "BaggingRegressor", "LGBMRegressor", "ExtraTreesRegressor", "XGBRegressor"],
 "Árbol simple": ["DecisionTreeRegressor", "ExtraTreeRegressor"],
 "Kernel / SVM": ["SVR", "NuSVR", "KernelRidge", "GaussianProcessRegressor"],
 "Vecinos": ["KNeighborsRegressor"], "Red neuronal": ["MLPRegressor"], "Referencia": ["DummyRegressor"],
}
mapa = {m: f for f, ms in familia.items() for m in ms}
models["Familia"] = models.index.map(mapa).fillna("Otro")
models.insert(0, "Ranking", range(1, len(models) + 1))
TABLAS["20_E2_LazyPredict_corregido"] = models.reset_index()

res_fam = (models.groupby("Familia")
           .agg(n_modelos=("R-Squared", "size"), R2_max=("R-Squared", "max"), R2_mediana=("R-Squared", "median"),
                R2_min=("R-Squared", "min"), RMSE_min=("RMSE", "min"), tiempo_total_s=("Time Taken", "sum"))
           .sort_values("R2_max", ascending=False))
res_fam["pct_tiempo"] = 100 * res_fam.tiempo_total_s / res_fam.tiempo_total_s.sum()
TABLAS["21_Resumen_por_familia"] = res_fam.reset_index()

antes_despues = pd.DataFrame({"R2_original_7var": mod_rep["R-Squared"],
                              "R2_corregido_28var": models["R-Squared"]}).dropna()
antes_despues["mejora"] = antes_despues.R2_corregido_28var - antes_despues.R2_original_7var
TABLAS["22_Antes_vs_despues"] = antes_despues.sort_values("R2_corregido_28var", ascending=False).reset_index() \
    .rename(columns={"index": "Model"})

# Gráfico: ranking R²
validos = models[models["R-Squared"] > 0].sort_values("R-Squared")
fig, ax = plt.subplots(figsize=(9, 9))
ax.barh(validos.index, validos["R-Squared"], color=AZUL, height=.65)
for i, v in enumerate(validos["R-Squared"]):
    if i >= len(validos) - 5:
        ax.text(v + .005, i, f"{v:.3f}", va="center", fontsize=8, color="#52514e")
ax.set(title="LazyPredict: R² en prueba (modelos con R² > 0)", xlabel="R²", xlim=(0, .8))
guardar("10_ranking_r2", "Ranking LazyPredict por R²")

# Gráfico: antes vs después
ad = antes_despues[antes_despues.R2_corregido_28var > 0].sort_values("R2_corregido_28var")
fig, ax = plt.subplots(figsize=(9, 9))
for i, (_, r) in enumerate(ad.iterrows()):
    ax.plot([r.R2_original_7var, r.R2_corregido_28var], [i, i], color="#d5d4cf", lw=2, zorder=1)
ax.scatter(ad.R2_original_7var, range(len(ad)), color=PAL[1], s=36, zorder=3, label="Original (7 variables)")
ax.scatter(ad.R2_corregido_28var, range(len(ad)), color=AZUL, s=36, zorder=3, label="Corregido (28 variables)")
ax.set_yticks(range(len(ad))); ax.set_yticklabels(ad.index, fontsize=8); ax.axvline(0, color=GRIS, lw=1)
ax.set(title="Efecto de la corrección en el R² de cada modelo", xlabel="R² en prueba")
ax.legend(loc="upper center", bbox_to_anchor=(.45, -.05), fontsize=8)
guardar("11_antes_despues", "R² antes y después de corregir")

# Gráfico: precisión vs costo
fig, ax = plt.subplots(figsize=(10, 5.2))
vis_m = models[models["R-Squared"] > 0]
for i, f in enumerate(res_fam.index):
    d = vis_m[vis_m.Familia == f]
    if not d.empty:
        ax.scatter(d["Time Taken"], d["R-Squared"], s=45, color=PAL[i % 8], label=f, edgecolor="white", lw=1.5, zorder=3)
ax.set(xscale="log", title="Precisión vs. costo computacional", xlabel="tiempo (s, log)", ylabel="R² en prueba")
ax.legend(fontsize=8, ncol=4, loc="upper center", bbox_to_anchor=(.5, -.14))
guardar("12_r2_vs_tiempo", "Precisión vs. costo computacional")

# Techo teórico
techo = eta2(df["nacionalidad"], y)
clave = lambda Xm: Xm.filter(like="nacionalidad").astype(str).agg("".join, axis=1)
pred_nac = clave(X_test).map(y_train.groupby(clave(X_train)).mean())
TABLAS["23_Techo_teorico"] = pd.DataFrame({
    "indicador": ["eta² de nacionalidad (todo el dataset)", "R² prueba usando solo la media por nacionalidad",
                  "Mejor R² de LazyPredict", "Tiempo total LazyPredict (s)"],
    "valor": [techo, r2_score(y_test, pred_nac), models["R-Squared"].max(), t_lazy]})

# =============================================================================
# 8. E3 - ESTABILIDAD CON VARIAS SEMILLAS
# =============================================================================
print(f"\n[8] E3: estabilidad con {N_SEMILLAS} particiones (puede tardar ~1 min)")
filas = []
for s in range(N_SEMILLAS):
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=s)
    m = lazy(Xtr, Xte, ytr, yte).reset_index()
    m["semilla"] = s
    m["rank"] = m["R-Squared"].rank(ascending=False)
    filas.append(m)
    print(f"   semilla {s}: mejor = {m.iloc[0]['Model']} (R² = {m.iloc[0]['R-Squared']:.4f})")
semillas = pd.concat(filas, ignore_index=True)
TABLAS["24_E3_Semillas_detalle"] = semillas
est = (semillas.groupby("Model")
       .agg(R2_medio=("R-Squared", "mean"), R2_desv=("R-Squared", "std"), R2_min=("R-Squared", "min"),
            R2_max=("R-Squared", "max"), RMSE_medio=("RMSE", "mean"), rank_medio=("rank", "mean"),
            rank_mejor=("rank", "min"), rank_peor=("rank", "max"),
            veces_primero=("rank", lambda r: int((r == 1).sum())), tiempo_medio=("Time Taken", "mean"))
       .sort_values("R2_medio", ascending=False))
TABLAS["25_E3_Estabilidad"] = est.reset_index()

sel = est[est.R2_medio > 0.4].index[::-1]
fig, ax = plt.subplots(figsize=(9, 9))
boxh(ax, [semillas.loc[semillas.Model == m, "R-Squared"].values for m in sel], list(sel))
ax.set(title=f"R² en {N_SEMILLAS} particiones aleatorias", xlabel="R²")
guardar("13_estabilidad_semillas", "Estabilidad del R² entre particiones")

# =============================================================================
# 9. E4 - VALIDACIÓN CRUZADA REPETIDA
# =============================================================================
print("\n[9] E4: validación cruzada 5x3")
candidatos = {
    "OrthogonalMatchingPursuitCV": make_pipeline(StandardScaler(), OrthogonalMatchingPursuitCV()),
    "LassoCV": make_pipeline(StandardScaler(), LassoCV(random_state=SEMILLA)),
    "Ridge": make_pipeline(StandardScaler(), Ridge()),
    "LinearRegression": make_pipeline(StandardScaler(), LinearRegression()),
    "LinearRegression log(y)": TransformedTargetRegressor(
        make_pipeline(StandardScaler(), LinearRegression()), func=np.log, inverse_func=np.exp),
    "GradientBoosting": GradientBoostingRegressor(random_state=SEMILLA),
    "RandomForest": RandomForestRegressor(random_state=SEMILLA, n_jobs=-1),
    "LGBM": LGBMRegressor(random_state=SEMILLA, verbose=-1),
    "XGB": XGBRegressor(random_state=SEMILLA, n_jobs=-1),
    "MLP": make_pipeline(StandardScaler(), MLPRegressor(max_iter=1000, random_state=SEMILLA)),
    "Dummy (media)": DummyRegressor(),
}
cols_nac = [c for c in X.columns if c.startswith("nacionalidad_")]
cv = RepeatedKFold(n_splits=5, n_repeats=3, random_state=SEMILLA)
filas = []
for nombre, modelo in list(candidatos.items()) + [("LinearRegression solo nacionalidad", LinearRegression())]:
    Xm = X[cols_nac] if "solo nacionalidad" in nombre else X
    r = cross_validate(modelo, Xm, y, cv=cv, n_jobs=-1,
                       scoring=["r2", "neg_root_mean_squared_error", "neg_mean_absolute_error"])
    filas.append([nombre, Xm.shape[1], r["test_r2"].mean(), r["test_r2"].std(),
                  -r["test_neg_root_mean_squared_error"].mean(), -r["test_neg_mean_absolute_error"].mean(),
                  r["fit_time"].mean()])
    print(f"   {nombre:38s} R² = {r['test_r2'].mean():.4f} ± {r['test_r2'].std():.4f}")
cv_res = (pd.DataFrame(filas, columns=["modelo", "n_variables", "R2_medio", "R2_desv", "RMSE", "MAE", "t_ajuste_s"])
          .sort_values("R2_medio", ascending=False).reset_index(drop=True))
TABLAS["26_E4_Validacion_cruzada"] = cv_res

cvp = cv_res[cv_res.modelo != "Dummy (media)"].sort_values("R2_medio")
fig, ax = plt.subplots(figsize=(9, 5))
ax.errorbar(cvp.R2_medio, cvp.modelo, xerr=cvp.R2_desv, fmt="o", color=AZUL, ecolor="#9cbfe9",
            elinewidth=3, capsize=0, markersize=7)
ax.axvline(techo, color=NAVY, ls="--", lw=1)
ax.text(techo, len(cvp) - .4, f" techo eta² = {techo:.3f}", color=NAVY, fontsize=8)
ax.set(title="Validación cruzada 5×3: R² medio ± desviación", xlabel="R²")
guardar("14_validacion_cruzada", "Validación cruzada 5x3")

# =============================================================================
# 10. E5 - VALIDACIÓN TEMPORAL (2019-2023 -> 2024)
# =============================================================================
print("\n[10] E5: validación temporal")
tr = df.anio <= 2023
models_t = lazy(X[tr], X[~tr], y[tr], y[~tr])
comp = pd.DataFrame({"R2_aleatorio": models["R-Squared"], "R2_temporal_2024": models_t["R-Squared"],
                     "RMSE_temporal_2024": models_t["RMSE"]}).sort_values("R2_temporal_2024", ascending=False)
TABLAS["27_E5_Validacion_temporal"] = comp.reset_index().rename(columns={"index": "Model"})
print(comp.head(5).round(4).to_string())

# Concordancia de rankings
rk = pd.DataFrame({"aleatoria_s42": models["R-Squared"], "media_semillas": est["R2_medio"],
                   "temporal_2024": models_t["R-Squared"]}).dropna()
rho = rk.corr(method="spearman")
tau = pd.DataFrame({a: {b: stats.kendalltau(rk[a], rk[b])[0] for b in rk} for a in rk})
conc = pd.concat({"Spearman": rho, "Kendall": tau}).round(4).reset_index()
conc.columns = ["coeficiente", "esquema"] + list(rk.columns)
TABLAS["28_Concordancia_rankings"] = conc

fig, ax = plt.subplots(figsize=(6.4, 5.6))
v = rk[(rk.aleatoria_s42 > 0.3) & (rk.temporal_2024 > 0.3)]
ax.scatter(v.aleatoria_s42, v.temporal_2024, color=AZUL, s=30, edgecolor="white", lw=1.2, zorder=3)
lim = [0.35, 0.76]; ax.plot(lim, lim, color=GRIS, ls="--", lw=1)
ax.set(xlim=lim, ylim=lim, title=f"R² aleatorio vs. temporal (Spearman = {rho.iloc[0, 2]:.2f})",
       xlabel="R² partición aleatoria", ylabel="R² prueba 2024")
guardar("15_concordancia", "Concordancia aleatoria vs. temporal")

# =============================================================================
# 11. E6 - AJUSTE DE HIPERPARÁMETROS (GRADIENT BOOSTING)
# =============================================================================
print("\n[11] E6: GridSearch de Gradient Boosting")
grid = {"n_estimators": [100, 300], "learning_rate": [0.03, 0.1], "max_depth": [2, 3], "subsample": [0.8, 1.0]}
gs = GridSearchCV(GradientBoostingRegressor(random_state=SEMILLA), grid,
                  cv=KFold(5, shuffle=True, random_state=SEMILLA), scoring="r2", n_jobs=-1)
t0 = time.time(); gs.fit(X_train, y_train); t_gs = time.time() - t0
gs_tabla = pd.DataFrame(gs.cv_results_)[["params", "mean_test_score", "std_test_score", "rank_test_score"]]
gs_tabla["params"] = gs_tabla["params"].astype(str)
TABLAS["29_E6_GridSearch"] = gs_tabla.sort_values("rank_test_score")
TABLAS["30_E6_Resumen"] = pd.DataFrame({
    "indicador": ["Mejores hiperparámetros", "R² CV (entrenamiento)", "R² prueba (ajustado)",
                  "R² prueba (por defecto, LazyPredict)", "Tiempo de búsqueda (s)"],
    "valor": [str(gs.best_params_), gs.best_score_, r2_score(y_test, gs.predict(X_test)),
              models.loc["GradientBoostingRegressor", "R-Squared"], t_gs]})
print(f"   {gs.best_params_} | R² prueba = {r2_score(y_test, gs.predict(X_test)):.4f}")

# =============================================================================
# 12. E7 - MODELO FINAL
# =============================================================================
print("\n[12] E7: modelo final (OrthogonalMatchingPursuitCV)")
Xraw = df.drop(columns=["id", "mes", "fecha", OBJ])
cats = [c for c in Xraw.columns if not pd.api.types.is_numeric_dtype(Xraw[c])]
nums = [c for c in Xraw.columns if c not in cats]
pre = ColumnTransformer([("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cats),
                         ("num", StandardScaler(), nums)])
final = make_pipeline(pre, OrthogonalMatchingPursuitCV())
Xr_tr, Xr_te = Xraw.loc[X_train.index], Xraw.loc[X_test.index]
final.fit(Xr_tr, y_train)
pred = final.predict(Xr_te)

rf = RandomForestRegressor(random_state=SEMILLA, n_jobs=-1).fit(X_train, y_train)
metricas = pd.DataFrame({
    "modelo": ["OrthogonalMatchingPursuitCV (final)", "RandomForestRegressor (comparación)"],
    "R2_entrenamiento": [r2_score(y_train, final.predict(Xr_tr)), r2_score(y_train, rf.predict(X_train))],
    "R2_prueba": [r2_score(y_test, pred), r2_score(y_test, rf.predict(X_test))],
    "RMSE_prueba": [np.sqrt(mean_squared_error(y_test, pred)), np.sqrt(mean_squared_error(y_test, rf.predict(X_test)))],
    "MAE_prueba": [mean_absolute_error(y_test, pred), mean_absolute_error(y_test, rf.predict(X_test))],
})
metricas["brecha_sobreajuste"] = metricas.R2_entrenamiento - metricas.R2_prueba
TABLAS["31_E7_Metricas_final"] = metricas
print(metricas.round(4).to_string(index=False))

pi = permutation_importance(final, Xr_te, y_test, n_repeats=20, random_state=SEMILLA, scoring="r2")
imp = pd.DataFrame({"variable": Xr_te.columns, "importancia_media": pi.importances_mean,
                    "importancia_desv": pi.importances_std}).sort_values("importancia_media", ascending=False)
TABLAS["32_E7_Importancia"] = imp

coef = pd.Series(final[-1].coef_, index=final[0].get_feature_names_out())
coefs = coef.rename("coeficiente").reset_index().rename(columns={"index": "variable"})
coefs = pd.concat([pd.DataFrame({"variable": ["(intercepto)"], "coeficiente": [final[-1].intercept_]}), coefs])
coefs["seleccionado"] = coefs.coeficiente != 0
TABLAS["33_E7_Coeficientes"] = coefs
TABLAS["34_E7_Predicciones_prueba"] = pd.DataFrame({
    "nacionalidad": Xr_te["nacionalidad"].values, "real": y_test.values, "predicho": pred,
    "residuo": y_test.values - pred})

imp_s = imp.set_index("variable")["importancia_media"].sort_values()
fig, ax = plt.subplots(1, 3, figsize=(16, 4.4))
ax[0].barh(imp_s.index, imp_s.values, color=AZUL, height=.6)
ax[0].set(title="Importancia por permutación", xlabel="caída de R²")
for i, n in enumerate(nac_orden):
    mk = (Xr_te["nacionalidad"] == n).values
    ax[1].scatter(y_test.values[mk], pred[mk], s=10, alpha=.7, color=PAL[i], label=n)
ax[1].plot([25, 165], [25, 165], color=GRIS, ls="--", lw=1)
ax[1].set(title="Real vs. predicho", xlabel="real (S/)", ylabel="predicho (S/)"); ax[1].legend(fontsize=7, ncol=2)
ax[2].scatter(pred, y_test.values - pred, s=10, alpha=.6, color=AZUL); ax[2].axhline(0, color=NAVY, lw=1)
ax[2].set(title="Residuos vs. predicho", xlabel="predicho (S/)", ylabel="residuo (S/)")
guardar("16_modelo_final", "Diagnóstico del modelo final")

# =============================================================================
# 13. RESUMEN Y EXPORTACIÓN A EXCEL
# =============================================================================
print("\n[13] Exportando a Excel")
mejor = models.index[0]
resumen = pd.DataFrame({
    "indicador": [
        "Registros", "Predictores (tras one-hot con dtype=int)", "eta² nacionalidad (techo de R²)",
        "Mejor R² ejecución original (bug, 7 variables)", "Mejor modelo LazyPredict (corregido)",
        "R² mejor modelo", "RMSE mejor modelo (S/)", "Modelos evaluados", "Modelos con R² > 0,70",
        "Tiempo total LazyPredict (s)", f"Veces que {mejor} fue 1.° en {N_SEMILLAS} semillas",
        "R² medio CV 5x3 (OMP-CV)", "Mejor R² validación temporal 2024", "Spearman aleatorio vs temporal",
        "R² Gradient Boosting ajustado (prueba)", "R² prueba modelo final", "MAE modelo final (S/)",
        "Tiempo total del script (s)"],
    "valor": [
        len(df), X.shape[1], round(techo, 4), round(mod_rep["R-Squared"].max(), 4), mejor,
        round(models["R-Squared"].iloc[0], 4), round(models["RMSE"].iloc[0], 2), len(models),
        int((models["R-Squared"] > .70).sum()), round(t_lazy, 2),
        int(est.loc[mejor, "veces_primero"]) if mejor in est.index else "-",
        round(cv_res.set_index("modelo").loc["OrthogonalMatchingPursuitCV", "R2_medio"], 4),
        round(comp["R2_temporal_2024"].max(), 4), round(rho.iloc[0, 2], 4),
        round(r2_score(y_test, gs.predict(X_test)), 4), round(r2_score(y_test, pred), 4),
        round(mean_absolute_error(y_test, pred), 2), round(time.time() - T0, 1)]})
TABLAS = {"00_Resumen": resumen, **TABLAS}

from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.drawing.image import Image as XLImage

with pd.ExcelWriter(EXCEL, engine="openpyxl") as writer:
    for hoja, tabla in TABLAS.items():
        t = tabla.copy()
        for c in t.columns:                                   # Excel no acepta zonas horarias
            if pd.api.types.is_datetime64_any_dtype(t[c]):
                t[c] = t[c].dt.strftime("%Y-%m")
        t.to_excel(writer, sheet_name=hoja[:31], index=False)
        ws = writer.sheets[hoja[:31]]
        for celda in ws[1]:
            celda.font = Font(bold=True, color="FFFFFF")
            celda.fill = PatternFill("solid", fgColor="1F2A44")
            celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for col in ws.columns:
            largo = max(len(str(c.value)) if c.value is not None else 0 for c in col)
            ws.column_dimensions[col[0].column_letter].width = min(max(10, largo + 2), 55)
            for c in col[1:]:
                if isinstance(c.value, float):
                    c.number_format = "0.0000"
        ws.freeze_panes = "A2"

    ws = writer.book.create_sheet("Graficos")
    fila = 1
    for ruta, titulo in FIGURAS:
        ws.cell(row=fila, column=1, value=titulo).font = Font(bold=True, size=12, color="1F2A44")
        img = XLImage(ruta)
        escala = 900 / img.width
        img.width, img.height = int(img.width * escala), int(img.height * escala)
        ws.add_image(img, f"A{fila + 1}")
        fila += int(img.height / 20) + 4

print(f"\n   Excel:    {EXCEL}")
print(f"   Figuras:  {FIG}  ({len(FIGURAS)} archivos)")
print(f"   Hojas:    {len(TABLAS) + 1}")
print(f"\nTerminado en {time.time() - T0:.1f} s")
print("=" * 70)
print(resumen.to_string(index=False))
