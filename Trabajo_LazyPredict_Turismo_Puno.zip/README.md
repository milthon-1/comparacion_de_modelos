# Gasto promedio de turistas en Puno (2019–2024): EDA y comparación de modelos con LazyPredict — versión 2

Autor: Milton Flores Flores (código 231210) — FINESI, Universidad Nacional del Altiplano.

## Contenido

| Archivo / carpeta | Descripción |
|---|---|
| `Informe_EDA_LazyPredict_Turismo_Puno_v2.pdf` | Informe técnico (versión 2) |
| `informe_latex/` | Fuente LaTeX del informe (`informe.tex`) con sus figuras |
| `EDA_LazyPredict_Turismo_Puno.ipynb` | Notebook ejecutado, pasos 0–26 |
| `EDA_LazyPredict_Turismo_Puno.py` | El mismo notebook exportado como script |
| `turismo_puno_2019_2024.csv` | Dataset |
| `modelo_gasto_turista.joblib` | Modelo final guardado (regresión lineal con la nacionalidad + cuantiles de los intervalos) |
| `app_streamlit.py` | App mínima: nacionalidad → gasto esperado e intervalo de predicción al 95 % |
| `figuras/` | Las 18 figuras en PNG |
| `resultados/` | Todas las tablas de resultados en CSV |
| `requirements.txt` | Versiones exactas de las librerías |
| `analisis_completo_lazypredict.py` | Script que genera todos los resultados y el Excel (sus capturas de ejecución están en el Anexo D) |

## Cómo reproducir

```bash
python -m venv venv
venv\Scripts\activate            # Windows  (Linux/Mac: source venv/bin/activate)
pip install -r requirements.txt
jupyter nbconvert --to notebook --execute EDA_LazyPredict_Turismo_Puno.ipynb   # o abrirlo en VS Code / Jupyter
streamlit run app_streamlit.py
```

- El notebook busca primero el CSV en `C:\Users\lenovo\Downloads\archive (2)\` y, si no existe, en su misma carpeta.
- Tiempo de ejecución: unos 2,5 minutos.
- **Semilla única: 42** (partición 80/20, `RepeatedKFold` 5×3, modelos con azar, bootstrap y Monte Carlo).
- Los tiempos de entrenamiento cambian según el equipo; las métricas no.
- Con LazyPredict 0.2.x los resultados del ranking son los mismos. La función `verificar_X()` evita el error de las columnas `bool`.

## Compilar el informe

`informe_latex/informe.tex` se compila con **XeLaTeX** (dos pasadas). En Overleaf: Menu → Compiler → XeLaTeX.
Si faltan las fuentes Caladea o Inter, el documento usa automáticamente Latin Modern.
