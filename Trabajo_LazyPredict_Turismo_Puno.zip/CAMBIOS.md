# Cambios de la versión 2

## 1. Correcciones
- Referencias cruzadas: "paso 16" → sección 5.3 y "paso 14" → sección 5.1 (además de las nuevas referencias a las secciones 7 y 8).
- Resumen: ahora dice "el mejor R² fue ≈ 0 (0,003) y varios fueron muy negativos" (árbol −1,05; KernelRidge −8,0; GaussianProcess −234 512).
- Conclusión 1: título reescrito para que no se comprima la línea.
- Figuras: categóricas en malla 2×3 con etiquetas legibles (Fig. 4); leyenda del gráfico gasto vs. visitantes debajo del gráfico (Fig. 7); etiquetas con líneas guía en precisión vs. costo (Fig. 12).
- Paso 8: corregida la afirmación sobre 2020. El gasto por turista no cambia, pero los visitantes caen 85,6 %.
- Referencias (17 entradas) y tabla de versiones de librerías.

## 2. Rigor estadístico (pasos 18–20, sección 7)
- Games-Howell y Tukey HSD: 15/15 pares significativos (p < 10⁻¹²). IC bootstrap 95 % de las medias.
- ANOVA de dos vías (HC3) y prueba sobre los residuos: nada aporta además de la nacionalidad (residuos: p = 0,98).
- Techo teórico analítico (R²máx = 0,743 con CV = 17,2 %) y Monte Carlo (0,741; 95 % entre 0,709 y 0,771).
- Nadeau-Bengio con ajuste de Holm, y Friedman + Nemenyi (sección 8.2).

## 3. Modelado (pasos 12b, 21–23)
- GLM Gamma (enlace log), WLS y modelo con interacción nacionalidad × sitio en las mismas 15 particiones.
- Métricas por nacionalidad (RMSE, MAE, MAPE) e intervalos de predicción con su cobertura (tres métodos).
- Segunda solución al error (texto sin codificar) comparada con dtype=int.
- `verificar_X()`: assert defensivo antes de LazyPredict.

## 4. Valor aplicado (pasos 24–25, sección 9)
- Ingreso estimado por nacionalidad, sitio y año, con su gráfico.
- Recomendaciones para el turismo en Puno, con advertencia de dataset sintético.
- Modelo guardado con joblib y app Streamlit (`app_streamlit.py`), probada con `streamlit.testing`.

## 5. Presentación
- Abstract en inglés y keywords; diagrama de flujo de la metodología (TikZ); secciones de limitaciones y trabajo futuro;
  glosario; anexo de reproducibilidad (versiones, semillas, requirements.txt, README).
