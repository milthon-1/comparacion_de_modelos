# -*- coding: utf-8 -*-
"""
App mínima: gasto esperado de un turista en Puno según su nacionalidad.
Ejecutar (en la misma carpeta que modelo_gasto_turista.joblib):
    streamlit run app_streamlit.py
"""
import os
import joblib
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Gasto turístico en Puno", page_icon="🏔️")

RUTA_MODELO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "modelo_gasto_turista.joblib")


@st.cache_resource
def cargar_modelo():
    return joblib.load(RUTA_MODELO)


paquete = cargar_modelo()
modelo = paquete["modelo"]

st.title("Gasto esperado de un turista en Puno")
st.caption("Modelo: regresión lineal con la nacionalidad (equivalente a OrthogonalMatchingPursuitCV). "
           f"R² en validación cruzada 5×3 = {paquete['r2_cv']:.3f}. Datos 2019–2024 ({paquete['n_registros']} registros).")

nacionalidad = st.selectbox("Nacionalidad del turista", paquete["nacionalidades"])
visitantes = st.number_input("Número de visitantes del grupo (opcional, para estimar el ingreso)",
                             min_value=1, value=1, step=1)

gasto = float(modelo.predict(pd.DataFrame({"nacionalidad": [nacionalidad]}))[0])
inf, sup = gasto * (1 + paquete["q_inf"]), gasto * (1 + paquete["q_sup"])

c1, c2 = st.columns(2)
c1.metric("Gasto esperado por turista", f"S/ {gasto:,.2f}")
c2.metric("Intervalo de predicción al 95 %", f"S/ {inf:,.2f} – {sup:,.2f}")
if visitantes > 1:
    st.write(f"Ingreso esperado del grupo de {visitantes} visitantes: **S/ {gasto * visitantes:,.2f}** "
             f"(entre S/ {inf * visitantes:,.2f} y S/ {sup * visitantes:,.2f} si todos gastaran en el mismo extremo).")

st.subheader("Comparación entre nacionalidades")
tabla = pd.DataFrame({"nacionalidad": paquete["nacionalidades"]})
tabla["gasto esperado (S/)"] = modelo.predict(tabla[["nacionalidad"]]).round(2)
tabla["IP 95 % inferior"] = (tabla["gasto esperado (S/)"] * (1 + paquete["q_inf"])).round(2)
tabla["IP 95 % superior"] = (tabla["gasto esperado (S/)"] * (1 + paquete["q_sup"])).round(2)
st.dataframe(tabla.sort_values("gasto esperado (S/)", ascending=False), hide_index=True)
st.bar_chart(tabla.set_index("nacionalidad")["gasto esperado (S/)"])

st.info("Intervalos construidos con los cuantiles empíricos 2,5 % y 97,5 % del error relativo (cobertura "
        "verificada de 94,4 % en prueba). El dataset parece sintético: úsese con fines académicos.")
