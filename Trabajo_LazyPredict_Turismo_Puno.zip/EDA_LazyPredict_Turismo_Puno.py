#!/usr/bin/env python
# coding: utf-8

# # Gasto promedio de turistas en Puno (2019–2024)
# ## Análisis exploratorio de datos y comparación de modelos de regresión con LazyPredict
# 
# **Autor:** Milton Flores Flores · Código 231210
# **Universidad Nacional del Altiplano – FINESI**
# 
# **Objetivo:** predecir `gasto_promedio_soles` (gasto promedio por turista, en soles) a partir de
# las características del registro (sitio turístico, mes, temporada, festividad, nacionalidad,
# visitantes, clima, satisfacción y transporte), y comparar ~40 modelos de regresión con LazyPredict.
# 
# El notebook (versión 2) sigue cinco bloques:
# 1. **Análisis exploratorio de datos (EDA)**, pasos 0–9.
# 2. **Modelado y comparación con LazyPredict**, pasos 10–17 (incluye 12b: segunda solución al error).
# 3. **Rigor estadístico**, pasos 18–20.
# 4. **Modelos complementarios e incertidumbre**, pasos 21–23.
# 5. **Valor aplicado y reproducibilidad**, pasos 24–26.

# ## Paso 0. Librerías, estilo de gráficos y carga del dataset

# In[1]:


import os, time, warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

warnings.filterwarnings("ignore")
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 30)

# Paleta (orden fijo de colores categóricos) y estilo sobrio
PAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
AZUL, NAVY, GRIS = PAL[0], "#1f2a44", "#8a8986"
plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 160, "font.size": 10,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "axes.axisbelow": True, "grid.color": "#e6e5e1", "grid.linewidth": 0.6,
    "axes.edgecolor": "#b9b8b3", "axes.titleweight": "bold", "axes.titlesize": 11,
    "axes.titlecolor": NAVY, "legend.frameon": False,
})
os.makedirs("figuras", exist_ok=True); os.makedirs("resultados", exist_ok=True)
def boxh(ax, data, labels=None, **kw):
    """Boxplot horizontal compatible con matplotlib antiguo y nuevo."""
    try:
        return ax.boxplot(data, orientation="horizontal", tick_labels=labels, **kw)
    except TypeError:
        return ax.boxplot(data, vert=False, labels=labels, **kw)
def guardar(nombre):
    plt.tight_layout()
    plt.savefig(f"figuras/{nombre}.png", bbox_inches="tight")
    plt.show()

def verificar_X(X, n_esperado=None):
    """Assert defensivo antes de LazyPredict: sin columnas bool, todo numérico, sin nulos."""
    cols_bool = X.columns[X.dtypes == bool].tolist()
    assert not cols_bool, f"{len(cols_bool)} columnas bool que LazyPredict puede descartar: {cols_bool[:3]}"
    no_num = X.select_dtypes(exclude="number").columns.tolist()
    assert not no_num, f"Columnas no numéricas: {no_num}"
    assert not X.isna().any().any(), "Hay valores nulos en X"
    if n_esperado is not None:
        assert X.shape[1] == n_esperado, f"Se esperaban {n_esperado} columnas y hay {X.shape[1]}"
    print(f"verificar_X OK: {X.shape[0]} filas x {X.shape[1]} columnas numéricas, sin bool ni nulos")

SEMILLA = 42   # semilla única usada en particiones, validación cruzada, bootstrap y Monte Carlo

# Ruta: usa la de tu PC si existe; si no, el CSV junto al notebook
RUTA_PC = r"C:\Users\lenovo\Downloads\archive (2)\turismo_puno_2019_2024.csv"
RUTA = RUTA_PC if os.path.exists(RUTA_PC) else "turismo_puno_2019_2024.csv"
df = pd.read_csv(RUTA)
OBJ = "gasto_promedio_soles"
print("Filas x columnas:", df.shape)
df.head()


# ## Paso 1. Estructura del dataset y diccionario de variables

# In[2]:


diccionario = pd.DataFrame({
    "tipo_pandas": df.dtypes.astype(str),
    "valores_unicos": df.nunique(),
    "ejemplo": df.iloc[0],
})
diccionario["rol"] = "predictor"
diccionario.loc["id", "rol"] = "identificador (se excluye)"
diccionario.loc["mes", "rol"] = "redundante con mes_num (se excluye)"
diccionario.loc[OBJ, "rol"] = "VARIABLE OBJETIVO (y)"
diccionario


# **Interpretación.** El dataset tiene **2 484 registros y 15 columnas**. Cada fila resume un mes en un sitio turístico para un grupo de nacionalidad: 6 sitios × 6 nacionalidades × 69 meses. Hay 5 variables de texto (sitio, temporada, festividad, nacionalidad, transporte), 1 de texto redundante (`mes`, que repite `mes_num`) y 8 numéricas. `id` es solo un identificador y no aporta información, por eso se excluye junto con `mes`.

# ## Paso 2. Calidad de los datos: nulos, duplicados, rangos y consistencia

# In[3]:


print("Valores nulos por columna:\n", df.isna().sum().to_string())
print("\nFilas duplicadas (sin contar id):", df.drop(columns="id").duplicated().sum())

# Rangos lógicos
print("\nRangos:")
print(df[["num_visitantes", "temperatura_promedio_c", "precipitacion_mm",
          "satisfaccion_1_5", OBJ]].agg(["min", "max"]).T)

# ¿Cuántos meses hay por año? ¿Diseño balanceado?
print("\nRegistros por año:\n", df["anio"].value_counts().sort_index().to_string())
print("\nMeses distintos en 2024:", sorted(df.query("anio == 2024")["mes_num"].unique().tolist()))
print("\nCombinaciones únicas año-mes-sitio-nacionalidad:",
      df.groupby(["anio", "mes_num", "sitio_turistico", "nacionalidad"]).ngroups, "de", len(df))


# In[4]:


# Consistencia de 'mes' vs 'mes_num' y del clima por mes
print("¿Cada mes_num corresponde a un único 'mes'?",
      (df.groupby("mes_num")["mes"].nunique() == 1).all())
clima = df.groupby(["anio", "mes_num"])[["temperatura_promedio_c", "precipitacion_mm"]].nunique()
print("¿El clima es el mismo para todos los sitios en un mismo año-mes?", (clima == 1).all().all())


# **Interpretación.**
# - No hay valores nulos ni filas duplicadas: no hace falta imputar ni depurar.
# - Todos los rangos son lógicos (satisfacción entre 2,7 y 4,5; temperatura entre 0,7 y 9,7 °C, coherente con el altiplano).
# - **2024 está incompleto**: solo llega hasta septiembre (324 registros frente a 432 de los demás años). Esto se aprovecha en el paso 16 para una validación temporal.
# - El diseño es **perfectamente balanceado**: cada combinación año-mes-sitio-nacionalidad aparece una sola vez.
# - El clima (temperatura y precipitación) es el mismo para los 6 sitios en un mismo mes: es un dato regional, no del sitio. El balance perfecto y el clima idéntico sugieren que el dataset es **simulado o sintético** (proviene de Kaggle), lo cual se debe tener en cuenta al interpretar los resultados.

# ## Paso 3. Análisis univariado de la variable objetivo

# In[5]:


y = df[OBJ]
resumen_y = pd.Series({
    "media": y.mean(), "mediana": y.median(), "desv. estándar": y.std(),
    "coef. variación (%)": 100 * y.std() / y.mean(), "mínimo": y.min(), "máximo": y.max(),
    "asimetría": stats.skew(y), "curtosis (exceso)": stats.kurtosis(y),
})
print(resumen_y.round(3).to_string())
sw = stats.shapiro(y)
print(f"\nShapiro-Wilk: W = {sw.statistic:.4f}, p = {sw.pvalue:.2e}")

fig, ax = plt.subplots(1, 3, figsize=(13, 3.6))
ax[0].hist(y, bins=40, color=AZUL, edgecolor="white")
ax[0].axvline(y.mean(), color=NAVY, ls="--", lw=1.5, label=f"media = {y.mean():.1f}")
ax[0].set(title="Distribución del gasto promedio", xlabel="soles", ylabel="frecuencia"); ax[0].legend()
boxh(ax[1], [y.values], patch_artist=True, widths=.5,
              boxprops=dict(facecolor="#cfe0f6", edgecolor=AZUL), medianprops=dict(color=NAVY, lw=2))
ax[1].set(title="Diagrama de caja", xlabel="soles", yticks=[])
stats.probplot(y, dist="norm", plot=ax[2])
ax[2].get_lines()[0].set(markerfacecolor=AZUL, markeredgecolor=AZUL, markersize=3)
ax[2].get_lines()[1].set(color=NAVY)
ax[2].set_title("Gráfico Q-Q normal")
guardar("03_objetivo")


# **Interpretación.** El gasto promedio es de **S/ 86,5** (mediana S/ 84,0) con una dispersión alta (desviación de S/ 30,8; CV = 35,5 %). La distribución es casi simétrica (asimetría 0,25) pero **platicúrtica** (curtosis −0,80): más aplanada que una normal. Shapiro-Wilk rechaza la normalidad (p ≈ 1,8·10⁻²⁰) y el Q-Q muestra colas cortas. Esa forma "ancha y plana" suele aparecer cuando la variable es una **mezcla de varios grupos con medias distintas**, lo que se confirma en el paso 5. No hay atípicos en el gasto.

# ## Paso 4. Análisis univariado de los predictores

# In[6]:


num = ["num_visitantes", "temperatura_promedio_c", "precipitacion_mm", "satisfaccion_1_5"]
print(df[num].describe().T.assign(asimetria=df[num].skew()).round(2))

fig, ax = plt.subplots(1, 4, figsize=(14, 3.2))
for a, c in zip(ax, num):
    a.hist(df[c], bins=30, color=AZUL, edgecolor="white")
    a.set(title=c, ylabel="frecuencia")
guardar("04a_numericas")


# In[7]:


cat = ["sitio_turistico", "nacionalidad", "temporada", "festividad", "tipo_transporte"]
# Malla 2x3 para que las etiquetas de los ejes sean legibles (corrección de la versión 1)
fig, axs = plt.subplots(2, 3, figsize=(14, 7.5))
for a, c in zip(axs.flat, cat):
    vc = df[c].value_counts()
    a.barh(vc.index[::-1], vc.values[::-1], color=AZUL, height=.6)
    for i, v in enumerate(vc.values[::-1]):
        a.text(v + 8, i, str(v), va="center", fontsize=9, color="#52514e")
    a.set_title(c, fontsize=12); a.set_xlabel("registros", fontsize=10)
    a.tick_params(axis="both", labelsize=10); a.set_xlim(0, vc.max() * 1.18)
axs.flat[-1].axis("off")
guardar("04b_categoricas")


# **Interpretación.**
# - `num_visitantes` es muy asimétrica a la derecha (asimetría 3,19): la mayoría de registros tiene pocos visitantes y unos pocos llegan a 2 200. Es la única variable con atípicos.
# - Temperatura y precipitación tienen distribuciones bimodales, típicas del ciclo seco/lluvioso del altiplano.
# - La satisfacción está concentrada entre 3,4 y 3,9.
# - Sitios y nacionalidades están perfectamente balanceados (414 registros cada uno). Temporada, festividad y transporte no lo están, pero eso se explica por el calendario y la geografía (paso 7).

# ## Paso 5. Relación de cada predictor categórico con el gasto (bivariado)

# In[8]:


def eta2(g, y):
    """Proporción de la varianza de y explicada por los grupos (eta cuadrado)."""
    m = y.groupby(g).transform("mean")
    return 1 - ((y - m) ** 2).sum() / ((y - y.mean()) ** 2).sum()

filas = []
for c in cat + ["anio", "mes_num", "tiene_festividad"]:
    grupos = [v[OBJ].values for _, v in df.groupby(c)]
    F = stats.f_oneway(*grupos)
    K = stats.kruskal(*grupos)
    filas.append([c, df[c].nunique(), F.statistic, F.pvalue, K.pvalue, eta2(df[c], df[OBJ])])
pruebas = (pd.DataFrame(filas, columns=["variable", "niveles", "F (ANOVA)", "p ANOVA",
                                        "p Kruskal-Wallis", "eta²"])
           .sort_values("eta²", ascending=False).reset_index(drop=True))
pruebas.to_csv("resultados/pruebas_bivariadas.csv", index=False)
pruebas.round(4)


# In[9]:


fig, ax = plt.subplots(2, 3, figsize=(15, 8))
for a, c in zip(ax.flat, ["nacionalidad", "sitio_turistico", "tipo_transporte",
                          "temporada", "festividad", "anio"]):
    orden = df.groupby(c)[OBJ].median().sort_values().index
    boxh(a, [df.loc[df[c] == k, OBJ].values for k in orden],
              [str(k) for k in orden], patch_artist=True, widths=.6,
              boxprops=dict(facecolor="#cfe0f6", edgecolor=AZUL), medianprops=dict(color=NAVY, lw=2),
              whiskerprops=dict(color=AZUL), capprops=dict(color=AZUL),
              flierprops=dict(marker="o", markersize=2, markerfacecolor=AZUL, markeredgecolor=AZUL))
    e = pruebas.set_index("variable").loc[c, "eta²"]
    a.set(title=f"Gasto según {c}  (eta² = {e:.3f})", xlabel="gasto promedio (S/)", ylabel="")
guardar("05_boxplots_categoricas")


# **Interpretación (hallazgo central del EDA).** De todas las variables, **solo la nacionalidad se relaciona con el gasto**: F = 1 409, p < 0,001 y **η² = 0,740**. Es decir, la nacionalidad sola explica el 74 % de la variación del gasto. Las demás tienen p > 0,36 y η² < 0,002: el sitio, la temporada, la festividad, el transporte, el año y el mes **no cambian el gasto** de forma significativa. Kruskal-Wallis (que no supone normalidad) llega a la misma conclusión.
# 
# El orden por gasto medio es: estadounidense (S/ 122) > europeo (S/ 111) > asiático (S/ 95) > otro (S/ 80) > latinoamericano (S/ 65) > peruano (S/ 45).

# ## Paso 6. Correlaciones entre variables numéricas

# In[10]:


cols_num = ["anio", "mes_num", "tiene_festividad", "num_visitantes", "temperatura_promedio_c",
            "precipitacion_mm", "satisfaccion_1_5", OBJ]
pear = df[cols_num].corr()
spear = df[cols_num].corr(method="spearman")
print("Correlación con el gasto:")
print(pd.DataFrame({"Pearson": pear[OBJ], "Spearman": spear[OBJ]}).drop(OBJ).round(3))

fig, ax = plt.subplots(1, 2, figsize=(14, 5.4))
for a, M, t in [(ax[0], pear, "Pearson"), (ax[1], spear, "Spearman")]:
    sns.heatmap(M, annot=True, fmt=".2f", cmap="RdBu_r", center=0, vmin=-1, vmax=1,
                linewidths=1, linecolor="white", ax=a, cbar_kws={"shrink": .7}, annot_kws={"size": 8})
    a.set_title(f"Matriz de correlación de {t}")
guardar("06_correlaciones")


# In[11]:


fig, ax = plt.subplots(1, 2, figsize=(13, 5.0))
nac_orden = df.groupby("nacionalidad")[OBJ].mean().sort_values(ascending=False).index
for i, n in enumerate(nac_orden):
    d = df[df.nacionalidad == n]
    ax[0].scatter(d.num_visitantes, d[OBJ], s=9, alpha=.55, color=PAL[i], label=n)
ax[0].set(xscale="log", title="Gasto vs. número de visitantes (escala log)",
          xlabel="visitantes (log)", ylabel="gasto promedio (S/)")
# Leyenda debajo del gráfico para no tapar los puntos (corrección de la versión 1)
ax[0].legend(fontsize=9, ncol=3, markerscale=2.2, loc="upper center", bbox_to_anchor=(.5, -.16))
vis = df.groupby("nacionalidad")["num_visitantes"].mean().reindex(nac_orden)
ax[1].bar(vis.index, vis.values, color=AZUL, width=.6)
ax[1].set(title="Visitantes promedio por registro según nacionalidad", ylabel="visitantes")
ax[1].tick_params(axis="x", rotation=25)
guardar("06b_visitantes")
print("Correlación visitantes-gasto DENTRO de cada nacionalidad:")
print(df.groupby("nacionalidad").apply(lambda d: d["num_visitantes"].corr(d[OBJ])).round(3).to_string())


# **Interpretación.** Ninguna variable numérica se correlaciona con el gasto (|r| < 0,09). La única con una correlación algo mayor es `num_visitantes` (Pearson −0,09; Spearman −0,13), pero es un **efecto de confusión**: los peruanos son el grupo con más visitantes (309 por registro) y a la vez el que menos gasta. Dentro de cada nacionalidad la correlación visitantes-gasto es prácticamente cero (entre −0,09 y 0,06). Tampoco hay correlaciones fuertes entre los predictores numéricos, así que no hay problemas graves de multicolinealidad entre ellos.

# ## Paso 7. Relaciones entre predictores: redundancias (V de Cramér)

# In[12]:


def cramer_v(a, b):
    tabla = pd.crosstab(a, b)
    chi2 = stats.chi2_contingency(tabla, correction=False)[0]
    n = tabla.values.sum(); r, k = tabla.shape
    return np.sqrt(chi2 / (n * (min(r, k) - 1)))

vars_cat = ["mes_num", "temporada", "festividad", "tiene_festividad", "sitio_turistico",
            "tipo_transporte", "nacionalidad"]
V = pd.DataFrame([[cramer_v(df[a], df[b]) for b in vars_cat] for a in vars_cat],
                 index=vars_cat, columns=vars_cat)
plt.figure(figsize=(7.5, 6))
sns.heatmap(V, annot=True, fmt=".2f", cmap="Blues", vmin=0, vmax=1, linewidths=1, linecolor="white")
plt.title("V de Cramér entre variables categóricas")
guardar("07_cramer")
print(pd.crosstab(df.sitio_turistico, df.tipo_transporte))


# In[13]:


# Mes -> temporada y festividad, y clima mensual
print(df.groupby("mes_num").agg(temporada=("temporada", "first"), festividad=("festividad", "first"),
                                temp_media=("temperatura_promedio_c", "mean"),
                                precip_media=("precipitacion_mm", "mean")).round(1))


# **Interpretación.** Hay **redundancias fuertes** entre los predictores:
# - `mes_num` determina por completo la `temporada` y la `festividad` (V de Cramér = 1): cada mes tiene siempre la misma temporada y la misma festividad. `tiene_festividad` también se deduce del mes.
# - El clima mensual también depende del mes (lluvias de diciembre a marzo, heladas de junio-julio).
# - `sitio_turistico` y `tipo_transporte` tienen una asociación moderada-fuerte (V = 0,50): la lancha solo aparece en las islas (Uros y Taquile) y ahí no hay transporte propio ni público.
# - `temporada` y `festividad` también se asocian (V = 0,73), porque ambas dependen del mes.
# - La nacionalidad es **independiente** de los demás predictores (V ≈ 0).
# 
# Estas redundancias no afectan mucho a los modelos con regularización o a los árboles, pero sí producen variables que no aportan información nueva.

# ## Paso 8. Evolución temporal y heterocedasticidad

# In[14]:


df["fecha"] = pd.to_datetime(dict(year=df.anio, month=df.mes_num, day=1))
serie = df.groupby(["fecha", "nacionalidad"])[OBJ].mean().unstack()[nac_orden]
fig, ax = plt.subplots(figsize=(13, 4.4))
for i, n in enumerate(nac_orden):
    ax.plot(serie.index, serie[n], lw=2, color=PAL[i], label=n)
    ax.text(serie.index[-1] + pd.Timedelta(days=25), serie[n].iloc[-3:].mean(), n,
            color="#52514e", fontsize=8, va="center")
ax.set(title="Gasto promedio mensual por nacionalidad (media de los 6 sitios)",
       ylabel="gasto promedio (S/)")
ax.legend(ncol=6, fontsize=8, loc="upper center", bbox_to_anchor=(.5, -.08))
guardar("08a_serie")

disp = df.groupby("nacionalidad")[OBJ].agg(media="mean", desv="std").reindex(nac_orden)
disp["CV_%"] = 100 * disp.desv / disp.media
print(disp.round(2))

# El gasto no cambia en 2020, pero el número de visitantes sí: se reporta para no confundir ambos efectos
por_anio = df.groupby("anio").agg(gasto_medio=(OBJ, "mean"), visitantes=("num_visitantes", "sum"))
por_anio["var_visitantes_%"] = 100 * por_anio.visitantes.pct_change()
print("\nGasto medio y visitantes totales por año:"); print(por_anio.round(2))


# In[15]:


fig, ax = plt.subplots(figsize=(6, 4))
ax.scatter(disp.media, disp.desv, s=60, color=AZUL, zorder=3)
for n, r in disp.iterrows():
    ax.annotate(n, (r.media, r.desv), xytext=(6, -3), textcoords="offset points", fontsize=8)
b = np.polyfit(disp.media, disp.desv, 1)
xx = np.linspace(40, 125, 10); ax.plot(xx, np.polyval(b, xx), color=GRIS, ls="--", lw=1)
ax.set(title="Desviación estándar crece con la media", xlabel="media del gasto (S/)",
       ylabel="desviación estándar (S/)")
guardar("08b_heterocedasticidad")
lev = stats.levene(*[v[OBJ].values for _, v in df.groupby("nacionalidad")])
print(f"Levene (igualdad de varianzas entre nacionalidades): W = {lev.statistic:.1f}, p = {lev.pvalue:.2e}")


# **Interpretación.** El gasto de cada nacionalidad se mantiene **estable entre 2019 y 2024**, sin tendencia ni estacionalidad. En 2020 el gasto medio por turista no cambia (S/ 87,1 frente a S/ 86,6 en 2019), aunque el **número de visitantes cae 85,6 %** (de 84 648 a 12 225): el dataset simula la caída de la demanda durante la pandemia, pero no un cambio en el gasto por persona. Las 6 curvas no se cruzan: el nivel de gasto lo fija la nacionalidad.
# 
# La desviación estándar crece en proporción a la media (CV constante ≈ 17 % en todos los grupos) y Levene rechaza la igualdad de varianzas (p < 0,001). Esto es **heterocedasticidad multiplicativa**: los grupos que más gastan también varían más. Por eso en el paso 14 se prueba también una regresión sobre log(gasto).

# ## Paso 9. Valores atípicos (criterio IQR)

# In[16]:


def atipicos_iqr(s):
    q1, q3 = s.quantile([.25, .75]); iqr = q3 - q1
    return ((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum()

at = pd.DataFrame({
    "global": {c: atipicos_iqr(df[c]) for c in num + [OBJ]},
    "dentro de nacionalidad": {c: df.groupby("nacionalidad")[c].apply(atipicos_iqr).sum() for c in num + [OBJ]},
})
at["% global"] = (100 * at["global"] / len(df)).round(1)
at


# **Interpretación.** Solo `num_visitantes` tiene atípicos (245 registros, 9,9 %), por su fuerte asimetría. Son valores plausibles (meses de festividad con mucha afluencia), no errores, por lo que **no se eliminan**. Como esa variable no influye en el gasto, sus atípicos no afectan la predicción.

# ## Conclusiones del análisis exploratorio
# 
# 1. **Datos limpios:** sin nulos, sin duplicados, rangos coherentes y diseño balanceado (probablemente sintético).
# 2. **Un solo predictor relevante:** la nacionalidad explica el 74 % de la varianza del gasto (η² = 0,740). El resto de variables tiene un efecto nulo.
# 3. **Techo de predicción:** si solo la nacionalidad importa, ningún modelo debería superar un R² cercano a 0,74. El 26 % restante es ruido aleatorio dentro de cada grupo (CV ≈ 17 %).
# 4. **Redundancias:** mes → temporada → festividad; sitio → transporte.
# 5. **Heterocedasticidad multiplicativa** del gasto según la nacionalidad.
# 6. **Confusión** en la relación visitantes-gasto, causada por la nacionalidad.
# 
# **Hipótesis para el modelado:** los modelos lineales simples deberían ganar, y los modelos complejos (árboles profundos, kernels) se arriesgan a sobreajustar el ruido.

# # BLOQUE 2. Comparación de modelos con LazyPredict

# ## Paso 10. Diagnóstico del código original (¿por qué R² ≈ 0?)

# In[17]:


X_orig = pd.get_dummies(df.drop(columns=["id", "mes", "fecha", OBJ]), drop_first=True)
print("Tipos de columnas tras get_dummies:")
print(X_orig.dtypes.value_counts().to_string())
print("\nColumnas numéricas (int/float):", X_orig.select_dtypes("number").columns.tolist())


# **Diagnóstico.** `pd.get_dummies()` crea las columnas dummy con tipo **`bool`** (pandas ≥ 2.0). Las versiones antiguas de LazyPredict (0.2.x) arman su preprocesamiento seleccionando solo columnas `number` (numéricas) y `object` (texto): **las columnas `bool` no entran en ninguna de las dos listas y se descartan en silencio**.
# 
# Eso se ve en el log de la ejecución original: `[LightGBM] ... number of used features: 7`. Los modelos solo recibieron las 7 numéricas originales y **perdieron la nacionalidad**, que es la única variable que explica el gasto. Por eso todos los modelos dieron R² ≈ 0 y el `DummyRegressor` (que predice la media) quedó a la par de los demás.
# 
# A continuación se replica el resultado original entrenando solo con esas 7 columnas.

# In[18]:


from lazypredict.Supervised import LazyRegressor
from sklearn.model_selection import train_test_split

# Réplica de lo que entrenó la versión original de LazyPredict: solo las 7 numéricas
X_rep = X_orig.select_dtypes("number")
Xtr, Xte, ytr, yte = train_test_split(X_rep, df[OBJ], test_size=0.2, random_state=42)
mod_rep, _ = LazyRegressor(verbose=0, ignore_warnings=True).fit(Xtr, Xte, ytr, yte)
mod_rep.head(6).round(3)


# **Resultado.** La réplica reproduce exactamente la salida original: R² ≈ 0,00 y RMSE ≈ 31,3, igual a la desviación estándar del gasto. Confirma el diagnóstico.
# 
# **Solución:** usar `pd.get_dummies(..., dtype=int)` para que las dummies sean enteros (0/1). Otra opción es pasarle a LazyPredict las columnas de texto sin codificar, para que él mismo haga el one-hot.

# ## Paso 11. Preparación corregida de los datos

# In[19]:


X = pd.get_dummies(df.drop(columns=["id", "mes", "fecha", OBJ]), drop_first=True, dtype=int)
y = df[OBJ]
# Verificación defensiva ANTES de llamar a LazyPredict (falla con un mensaje claro si hay columnas bool)
verificar_X(X, n_esperado=28)
print("Matriz X:", X.shape, "| columnas booleanas:", (X.dtypes == bool).sum())

# Prueba de que la verificación habría detectado el error original
try:
    verificar_X(X_orig)
except AssertionError as e:
    print("La verificación detecta el error original ->", str(e)[:110], "...")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("Entrenamiento:", X_train.shape, " Prueba:", X_test.shape)
print(X.columns.tolist())


# **Interpretación.** Con `dtype=int`, la matriz queda con **28 columnas numéricas**: 7 numéricas originales + 21 dummies (con `drop_first=True` se elimina una categoría por variable para evitar colinealidad perfecta). Se mantiene la partición 80/20 con `random_state=42`, igual que en el código original, para que la comparación sea directa.

# ## Paso 12. Ejecución de LazyRegressor (partición aleatoria 80/20)

# In[20]:


t0 = time.time()
reg = LazyRegressor(verbose=0, ignore_warnings=True, custom_metric=None)
models, predictions = reg.fit(X_train, X_test, y_train, y_test)
print(f"Tiempo total de LazyPredict: {time.time() - t0:.1f} s  |  modelos evaluados: {len(models)}")
models.to_csv("resultados/lazypredict_corregido.csv")
mod_rep.to_csv("resultados/lazypredict_replica_original.csv")
models.round(4)


# In[21]:


validos = models[models["R-Squared"] > 0].sort_values("R-Squared")
fig, ax = plt.subplots(figsize=(9, 9))
ax.barh(validos.index, validos["R-Squared"], color=AZUL, height=.65)
ax.axvline(models.loc["DummyRegressor", "R-Squared"], color=GRIS, lw=1)
for i, v in enumerate(validos["R-Squared"]):
    if i >= len(validos) - 5:
        ax.text(v + .005, i, f"{v:.3f}", va="center", fontsize=8, color="#52514e")
ax.set(title="R² en el conjunto de prueba (modelos con R² > 0)", xlabel="R²", xlim=(0, .8))
guardar("12a_ranking_r2")
print("Modelos con R² negativo (peores que predecir la media):",
      models[models["R-Squared"] <= 0].index.tolist())


# In[22]:


familia = {
 "Lineal": ["OrthogonalMatchingPursuitCV","SGDRegressor","LassoCV","LassoLarsIC","LarsCV","LassoLarsCV",
            "LinearRegression","TransformedTargetRegressor","Ridge","HuberRegressor","BayesianRidge","RidgeCV",
            "ElasticNetCV","Lars","Lasso","LassoLars","LinearSVR","ElasticNet","RANSACRegressor",
            "OrthogonalMatchingPursuit","PassiveAggressiveRegressor","QuantileRegressor"],
 "GLM": ["PoissonRegressor","TweedieRegressor","GammaRegressor"],
 "Ensamble de árboles": ["GradientBoostingRegressor","AdaBoostRegressor","RandomForestRegressor",
            "HistGradientBoostingRegressor","BaggingRegressor","LGBMRegressor","ExtraTreesRegressor","XGBRegressor"],
 "Árbol simple": ["DecisionTreeRegressor","ExtraTreeRegressor"],
 "Kernel / SVM": ["SVR","NuSVR","KernelRidge","GaussianProcessRegressor"],
 "Vecinos": ["KNeighborsRegressor"], "Red neuronal": ["MLPRegressor"], "Referencia": ["DummyRegressor"],
}
mapa = {m: f for f, ms in familia.items() for m in ms}
models["Familia"] = models.index.map(mapa).fillna("Otro")
res_fam = (models.groupby("Familia")
           .agg(n=("R-Squared", "size"), R2_max=("R-Squared", "max"), R2_mediana=("R-Squared", "median"),
                RMSE_min=("RMSE", "min"), tiempo_medio_s=("Time Taken", "mean"))
           .sort_values("R2_max", ascending=False))
res_fam.to_csv("resultados/resumen_por_familia.csv")
res_fam.round(3)


# In[23]:


fig, ax = plt.subplots(figsize=(10, 5.2))
fams = res_fam.index.tolist()
vis_m = models[models["R-Squared"] > 0]
for i, f in enumerate(fams):
    d = vis_m[vis_m.Familia == f]
    if d.empty:
        continue
    ax.scatter(d["Time Taken"], d["R-Squared"], s=45, color=PAL[i % 8], label=f,
               edgecolor="white", linewidth=1.5, zorder=3)
# Etiquetas ubicadas en zonas vacías y unidas al punto con una línea guía (corrección de la versión 1)
etiquetas = {"OrthogonalMatchingPursuitCV": (0.0105, 0.775), "GradientBoostingRegressor": (0.14, 0.775),
             "MLPRegressor": (0.26, 0.58), "RandomForestRegressor": (0.26, 0.545), "XGBRegressor": (0.027, 0.66)}
for m, (tx, ty) in etiquetas.items():
    if m in vis_m.index:
        ax.annotate(m, (vis_m.loc[m, "Time Taken"], vis_m.loc[m, "R-Squared"]), xytext=(tx, ty),
                    textcoords="data", fontsize=9, color="#333333",
                    arrowprops=dict(arrowstyle="-", color="#9a9994", lw=.8, shrinkB=4))
ax.set_ylim(top=0.80)
ax.set(xscale="log", title="Precisión vs. costo computacional", xlabel="tiempo de entrenamiento (s, log)",
       ylabel="R² en prueba")
ax.tick_params(labelsize=10)
ax.legend(fontsize=9, ncol=4, loc="upper center", bbox_to_anchor=(.5, -.14))
guardar("12b_r2_vs_tiempo")


# **Interpretación de la comparación LazyPredict.**
# - Con los datos corregidos, el R² sube de **≈ 0,00 a 0,730** y el RMSE baja de 31,3 a **16,3 soles**.
# - **Ganan los modelos lineales**: OrthogonalMatchingPursuitCV (R² = 0,730), SGD, LassoCV, Lars y LinearRegression quedan casi empatados (0,727–0,730). Las diferencias en la tercera decimal no son relevantes.
# - **Los ensambles de árboles no mejoran**: GradientBoosting (0,717) se acerca, pero RandomForest (0,681), LGBM (0,677) y XGBoost (0,634) quedan por debajo. Con mucho ruido y una relación aditiva simple, los árboles se ajustan al ruido.
# - **Peores:** árbol de decisión simple (0,476), SVR/NuSVR sin ajustar (≈ 0,49) y KernelRidge/GaussianProcess, con R² negativo (sin escalar el objetivo ni ajustar el kernel, extrapolan muy mal).
# - **Costo computacional:** los lineales tardan ~0,01–0,05 s; RandomForest y ExtraTrees ~0,7 s y el MLP ~0,7 s, es decir, **10 a 70 veces más tiempo para un resultado peor**. Todo LazyPredict corre en unos 6 s.

# ## Paso 12b. Segunda solución al error: pasar las columnas de texto sin codificar
# LazyPredict también puede hacer el *one-hot* por sí mismo si recibe las variables categóricas como texto.
# Aquí se compara esa vía con la corrección `dtype=int`, usando la misma partición 80/20.

# In[24]:


# Columnas de texto sin codificar. Se fuerzan a 'object' para que también funcione con versiones
# antiguas de LazyPredict (0.2.x), que solo reconocen el tipo object como categórico.
X_txt = df.drop(columns=["id", "mes", "fecha", OBJ]).copy()
cols_txt = [c for c in X_txt.columns if not pd.api.types.is_numeric_dtype(X_txt[c])]
X_txt[cols_txt] = X_txt[cols_txt].astype(object)
print("Columnas de texto:", cols_txt)

models_txt, _ = LazyRegressor(verbose=0, ignore_warnings=True).fit(
    X_txt.loc[X_train.index], X_txt.loc[X_test.index], y_train, y_test)

comp_sol = pd.DataFrame({"R2 dtype=int": models["R-Squared"], "R2 texto sin codificar": models_txt["R-Squared"]})
comp_sol["diferencia"] = comp_sol["R2 texto sin codificar"] - comp_sol["R2 dtype=int"]
comp_sol = comp_sol.sort_values("R2 texto sin codificar", ascending=False)
comp_sol.to_csv("resultados/comparacion_soluciones_bug.csv")
rho_sol = comp_sol[["R2 dtype=int", "R2 texto sin codificar"]].corr(method="spearman").iloc[0, 1]
print(f"Ganador con dtype=int: {models.index[0]} ({models['R-Squared'].iloc[0]:.4f})")
print(f"Ganador con texto:     {models_txt.index[0]} ({models_txt['R-Squared'].iloc[0]:.4f})")
print(f"Correlación de Spearman entre ambos rankings: {rho_sol:.3f}")
print("\nModelos con mayor diferencia entre las dos vías:")
print(comp_sol.reindex(comp_sol.diferencia.abs().sort_values(ascending=False).index).head(8).round(4))
comp_sol.head(8).round(4)


# **Interpretación.** Las dos vías corrigen el error y llevan al **mismo ganador** (OrthogonalMatchingPursuitCV, R² = 0,7303), pero no son equivalentes para todos los modelos: la correlación de Spearman entre los dos rankings es **0,850**.
# - Con `dtype=int` las dummies se tratan como numéricas y LazyPredict las **estandariza**. Con texto sin codificar, LazyPredict hace un one-hot **completo** (sin eliminar una categoría) y deja las dummies en 0/1, **sin estandarizar**.
# - Ese cambio de escala afecta a los modelos sensibles a ella. KernelRidge pasa de −6,94 a **0,726**: con el one-hot completo, la suma de las dummies de una variable es una columna constante que actúa como intercepto, y ese era justamente el problema de KernelRidge, que por defecto no tiene intercepto. En cambio, ElasticNet (0,640 → 0,283), KNN (0,576 → 0,268), SVR, Gamma y Tweedie empeoran, porque la penalización o la distancia ahora actúan sobre variables sin escalar.
# - **Conclusión:** la vía elegida no cambia la conclusión principal, pero sí el orden de los modelos sensibles a la escala. Se mantiene `dtype=int` con la verificación `verificar_X()` como opción por defecto, y se documenta la segunda vía.

# ## Paso 13. Techo teórico de predicción

# In[25]:


# Si el gasto depende casi solo de la nacionalidad, el mejor R² posible es su eta²
techo = eta2(df["nacionalidad"], df[OBJ])
pred_nac = y_train.groupby(X_train.filter(like="nacionalidad").astype(str).agg("".join, axis=1)).mean()
clave_te = X_test.filter(like="nacionalidad").astype(str).agg("".join, axis=1)
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
r2_media_nac = r2_score(y_test, clave_te.map(pred_nac))
print(f"eta² de nacionalidad en todo el dataset: {techo:.4f}")
print(f"R² en prueba prediciendo solo con la media de cada nacionalidad: {r2_media_nac:.4f}")
print(f"Mejor R² de LazyPredict: {models['R-Squared'].max():.4f}")


# **Interpretación.** Si se predice el gasto usando **solo la media de cada nacionalidad** (sin ningún modelo), se obtiene R² = 0,730 en prueba, **exactamente lo mismo que el mejor modelo de LazyPredict**. El mejor modelo ya alcanzó el techo teórico (η² = 0,740). El 26 % restante es variación aleatoria que ninguna variable del dataset puede explicar.

# ## Paso 14. Validación cruzada repetida de los modelos seleccionados

# In[26]:


from sklearn.model_selection import RepeatedKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.compose import TransformedTargetRegressor
from sklearn.linear_model import (LinearRegression, Ridge, LassoCV, OrthogonalMatchingPursuitCV)
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.dummy import DummyRegressor
from lightgbm import LGBMRegressor
from xgboost import XGBRegressor

candidatos = {
    "OrthogonalMatchingPursuitCV": make_pipeline(StandardScaler(), OrthogonalMatchingPursuitCV()),
    "LassoCV": make_pipeline(StandardScaler(), LassoCV(random_state=42)),
    "Ridge": make_pipeline(StandardScaler(), Ridge()),
    "LinearRegression": make_pipeline(StandardScaler(), LinearRegression()),
    "LinearRegression log(y)": TransformedTargetRegressor(
        make_pipeline(StandardScaler(), LinearRegression()), func=np.log, inverse_func=np.exp),
    "GradientBoosting": GradientBoostingRegressor(random_state=42),
    "RandomForest": RandomForestRegressor(random_state=42, n_jobs=-1),
    "LGBM": LGBMRegressor(random_state=42, verbose=-1),
    "XGB": XGBRegressor(random_state=42, n_jobs=-1),
    "MLP": make_pipeline(StandardScaler(), MLPRegressor(max_iter=1000, random_state=42)),
    "Dummy (media)": DummyRegressor(),
}
cols_nac = [c for c in X.columns if c.startswith("nacionalidad_")]
cv = RepeatedKFold(n_splits=5, n_repeats=3, random_state=42)
filas = []
for nombre, modelo in list(candidatos.items()) + [("LinearRegression solo nacionalidad", LinearRegression())]:
    Xm = X[cols_nac] if "solo nacionalidad" in nombre else X
    r = cross_validate(modelo, Xm, y, cv=cv, n_jobs=-1,
                       scoring=["r2", "neg_root_mean_squared_error", "neg_mean_absolute_error"])
    filas.append([nombre, Xm.shape[1], r["test_r2"].mean(), r["test_r2"].std(),
                  -r["test_neg_root_mean_squared_error"].mean(), -r["test_neg_mean_absolute_error"].mean(),
                  r["fit_time"].mean()])
cv_res = (pd.DataFrame(filas, columns=["modelo", "n_variables", "R2_medio", "R2_desv", "RMSE", "MAE", "t_ajuste_s"])
          .sort_values("R2_medio", ascending=False).reset_index(drop=True))
cv_res.to_csv("resultados/validacion_cruzada.csv", index=False)
cv_res.round(4)


# In[27]:


cvp = cv_res[cv_res.modelo != "Dummy (media)"].sort_values("R2_medio")
fig, ax = plt.subplots(figsize=(9, 5))
ax.errorbar(cvp.R2_medio, cvp.modelo, xerr=cvp.R2_desv, fmt="o", color=AZUL, ecolor="#9cbfe9",
            elinewidth=3, capsize=0, markersize=7)
ax.axvline(techo, color=NAVY, ls="--", lw=1)
ax.text(techo, len(cvp) - .4, f" techo eta² = {techo:.3f}", color=NAVY, fontsize=8)
ax.set(title="Validación cruzada 5×3: R² medio ± desviación", xlabel="R²")
guardar("14_cv")


# **Interpretación.** Una sola partición 80/20 puede ser engañosa, así que se repitió la evaluación con **validación cruzada de 5 particiones × 3 repeticiones (15 ajustes por modelo)**:
# - **OrthogonalMatchingPursuitCV** y la **regresión lineal solo con nacionalidad** empatan en el primer lugar (R² = 0,738 ± 0,008; RMSE = 15,7; MAE = 13,0 soles). OMP-CV, al elegir variables, se queda justamente con las 5 dummies de nacionalidad.
# - LassoCV, Ridge y LinearRegression quedan a menos de 0,005: incluir las otras 23 variables no ayuda.
# - Transformar a log(y) no mejora (0,732), aunque había heterocedasticidad: corrige la varianza, pero no agrega información.
# - El orden de LazyPredict se confirma: GradientBoosting (0,727) > RandomForest (0,700) > LGBM (0,692) > MLP (0,682) > XGB (0,648).
# - Las desviaciones (≈ 0,01) indican que el ranking es estable. El paso 22 comprueba si estas diferencias son estadísticamente significativas.
# 
# **Principio de parsimonia:** con el mismo desempeño, el modelo con 5 variables es preferible al de 28.

# ## Paso 15. Ajuste de hiperparámetros del mejor modelo de árboles

# In[28]:


from sklearn.model_selection import GridSearchCV, KFold
grid = {"n_estimators": [100, 300], "learning_rate": [0.03, 0.1], "max_depth": [2, 3],
        "subsample": [0.8, 1.0]}
gs = GridSearchCV(GradientBoostingRegressor(random_state=42), grid, cv=KFold(5, shuffle=True, random_state=42),
                  scoring="r2", n_jobs=-1)
t0 = time.time(); gs.fit(X_train, y_train); t_gs = time.time() - t0
print("Mejores hiperparámetros:", gs.best_params_)
print(f"R² CV (train): {gs.best_score_:.4f} | R² prueba: {r2_score(y_test, gs.predict(X_test)):.4f} | "
      f"tiempo búsqueda: {t_gs:.1f} s ({len(gs.cv_results_['params'])} combinaciones × 5 folds)")


# **Interpretación.** LazyPredict usa hiperparámetros por defecto. Para ver si los árboles quedaron en desventaja por eso, se ajustó GradientBoosting con una búsqueda en malla (16 combinaciones × 5 folds). El mejor ajuste usa **árboles muy poco profundos (max_depth = 2) y una tasa de aprendizaje baja**, es decir, el modelo más simple de la malla. Aun así llega a R² = 0,725 en prueba, **sin superar a los lineales** y con ~13 s de búsqueda frente a 0,01 s de una regresión lineal. Confirma que la limitación está en los datos, no en la configuración del modelo.

# ## Paso 16. Validación temporal: entrenar 2019–2023 y predecir 2024 (LazyPredict)

# In[29]:


tr = df.anio <= 2023
models_t, _ = LazyRegressor(verbose=0, ignore_warnings=True).fit(X[tr], X[~tr], y[tr], y[~tr])
print(f"Entrenamiento: {tr.sum()} registros (2019–2023) | Prueba: {(~tr).sum()} registros (2024)")
comp = pd.DataFrame({"R2 aleatorio": models["R-Squared"], "R2 temporal 2024": models_t["R-Squared"],
                     "RMSE temporal": models_t["RMSE"]}).sort_values("R2 temporal 2024", ascending=False)
comp.to_csv("resultados/lazypredict_temporal_2024.csv")
comp.head(12).round(4)


# **Interpretación.** En un caso real se predice el futuro con el pasado. Al entrenar con 2019–2023 y predecir 2024, los mejores modelos siguen siendo los lineales con regularización/selección (LassoLarsIC, LassoCV, OMP-CV) con **R² ≈ 0,710 y RMSE ≈ 16,4**, apenas por debajo de la partición aleatoria. El modelo **generaliza bien en el tiempo**, lo cual es esperable porque el gasto no tiene tendencia (paso 8).

# ## Paso 17. Modelo final: evaluación, residuos e importancia de variables

# In[30]:


from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.inspection import permutation_importance

Xraw = df.drop(columns=["id", "mes", "fecha", OBJ])
cats = Xraw.select_dtypes("object").columns.tolist() if Xraw.select_dtypes("object").shape[1] else \
       Xraw.select_dtypes(exclude="number").columns.tolist()
nums = Xraw.select_dtypes("number").columns.tolist()
pre = ColumnTransformer([("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cats),
                         ("num", StandardScaler(), nums)])
final = make_pipeline(pre, OrthogonalMatchingPursuitCV())
Xr_tr, Xr_te = Xraw.loc[X_train.index], Xraw.loc[X_test.index]
final.fit(Xr_tr, y_train)
pred = final.predict(Xr_te)
print(f"Modelo final OrthogonalMatchingPursuitCV -> R² = {r2_score(y_test, pred):.4f} | "
      f"RMSE = {np.sqrt(mean_squared_error(y_test, pred)):.2f} | MAE = {mean_absolute_error(y_test, pred):.2f} soles")

pi = permutation_importance(final, Xr_te, y_test, n_repeats=20, random_state=42, scoring="r2")
imp = pd.Series(pi.importances_mean, index=Xr_te.columns).sort_values()
print("\nImportancia por permutación (caída de R²):"); print(imp[::-1].round(4).to_string())


# In[31]:


fig, ax = plt.subplots(1, 3, figsize=(16, 4.4))
ax[0].barh(imp.index, imp.values, color=AZUL, height=.6)
ax[0].set(title="Importancia por permutación", xlabel="caída de R² al permutar")
nac_te = Xr_te["nacionalidad"]
for i, n in enumerate(nac_orden):
    m = nac_te == n
    ax[1].scatter(y_test[m], pred[m], s=10, alpha=.7, color=PAL[i], label=n)
lim = [25, 165]; ax[1].plot(lim, lim, color=GRIS, ls="--", lw=1)
ax[1].set(title="Real vs. predicho (prueba)", xlabel="gasto real (S/)", ylabel="gasto predicho (S/)",
          xlim=lim, ylim=lim)
ax[1].legend(fontsize=7, markerscale=1.8, ncol=2)
res = y_test - pred
ax[2].scatter(pred, res, s=10, alpha=.6, color=AZUL); ax[2].axhline(0, color=NAVY, lw=1)
ax[2].set(title="Residuos vs. predicho", xlabel="gasto predicho (S/)", ylabel="residuo (S/)")
guardar("17_modelo_final")
coef = pd.Series(final[-1].coef_, index=final[0].get_feature_names_out())
print("Coeficientes distintos de cero:", (coef != 0).sum(), "de", len(coef))
print(coef[coef != 0].sort_values().round(2).to_string())
print(f"Intercepto (gasto base del grupo de referencia, Asiático): {final[-1].intercept_:.2f} soles")


# **Interpretación del modelo final.** Se eligió **OrthogonalMatchingPursuitCV**: es el ganador de LazyPredict, empata en primer lugar en la validación cruzada, es el más rápido y es interpretable. Se reconstruyó con un `Pipeline` que codifica las variables internamente, para medir la importancia de cada variable original.
# - **Desempeño en prueba:** R² = 0,730; RMSE = 16,3 soles; MAE = 13,5 soles (error típico de ±13 soles sobre un gasto medio de 86).
# - **Importancia por permutación:** solo la nacionalidad importa. Al desordenarla el R² cae 1,40 puntos (el modelo pasa a ser peor que la media). Al desordenar cualquier otra variable la caída es ≈ 0.
# - **Coeficientes:** el modelo selecciona solo las 5 dummies de nacionalidad. Respecto al turista asiático (intercepto = S/ 95,3), un estadounidense gasta +26 soles, un europeo +16, un "otro" −15, un latinoamericano −30 y un peruano −50.
# - **Residuos:** se reparten alrededor de 0 sin sesgo, pero se abren a medida que crece el gasto predicho (forma de embudo), que es la heterocedasticidad multiplicativa del paso 8. Real vs. predicho muestra 6 franjas horizontales: el modelo predice un valor por nacionalidad.

# # BLOQUE 3. Rigor estadístico

# ## Paso 18. Comparaciones post hoc entre nacionalidades (Games-Howell y Tukey HSD)
# Como las varianzas difieren entre nacionalidades (Levene, paso 8), la prueba principal es **Games-Howell**,
# que no supone varianzas iguales. Tukey HSD se reporta como contraste. Las medias se acompañan de intervalos
# de confianza *bootstrap* al 95 % (10 000 remuestreos).

# In[32]:


import itertools

def games_howell(data, grupo, valor, alfa=0.05):
    # Games-Howell: t de Welch por par + distribución del rango studentizado con gl de Welch-Satterthwaite
    g = data.groupby(grupo)[valor]
    m, v, n = g.mean(), g.var(ddof=1), g.count()
    k = len(m); filas = []
    for a, b in itertools.combinations(m.index, 2):
        dif = m[a] - m[b]
        se2 = v[a] / n[a] + v[b] / n[b]; se = np.sqrt(se2)
        gl = se2 ** 2 / ((v[a] / n[a]) ** 2 / (n[a] - 1) + (v[b] / n[b]) ** 2 / (n[b] - 1))
        t = abs(dif) / se
        p = stats.studentized_range.sf(t * np.sqrt(2), k, gl)
        q = stats.studentized_range.ppf(1 - alfa, k, gl) / np.sqrt(2)
        filas.append([a, b, dif, se, t, gl, p, dif - q * se, dif + q * se])
    return pd.DataFrame(filas, columns=["grupo_A", "grupo_B", "diferencia", "error_est", "t", "gl",
                                        "p_ajustado", "IC95_inf", "IC95_sup"])

gh = games_howell(df, "nacionalidad", OBJ)
niveles = sorted(df.nacionalidad.unique())
tk = stats.tukey_hsd(*[df.loc[df.nacionalidad == k, OBJ].values for k in niveles])
gh["p_Tukey"] = [tk.pvalue[niveles.index(a), niveles.index(b)] for a, b in zip(gh.grupo_A, gh.grupo_B)]
gh.to_csv("resultados/posthoc_games_howell.csv", index=False)
print(f"Pares significativos (Games-Howell, p < 0,05): {(gh.p_ajustado < .05).sum()} de {len(gh)}")
print(f"p máximo Games-Howell: {gh.p_ajustado.max():.2e} | p máximo Tukey: {gh.p_Tukey.max():.2e}")
print(f"Diferencia más pequeña: {gh.loc[gh.diferencia.abs().idxmin(), ['grupo_A', 'grupo_B', 'diferencia']].tolist()}")

# Intervalos bootstrap de la media por nacionalidad
rng = np.random.default_rng(SEMILLA)
boot = []
for k in nac_orden:
    s = df.loc[df.nacionalidad == k, OBJ].values
    medias_b = rng.choice(s, size=(10000, len(s)), replace=True).mean(axis=1)
    boot.append([k, len(s), s.mean(), *np.percentile(medias_b, [2.5, 97.5])])
boot = pd.DataFrame(boot, columns=["nacionalidad", "n", "media", "IC95_inf", "IC95_sup"])
boot["semiancho"] = (boot.IC95_sup - boot.IC95_inf) / 2
boot.to_csv("resultados/bootstrap_medias.csv", index=False)
print(boot.round(2).to_string(index=False))
gh.round(4)


# In[33]:


fig, ax = plt.subplots(1, 2, figsize=(14, 4.8), gridspec_kw={"width_ratios": [1, 1.25]})
b = boot.iloc[::-1]
ax[0].errorbar(b.media, b.nacionalidad, xerr=[b.media - b.IC95_inf, b.IC95_sup - b.media], fmt="o",
               color=AZUL, ecolor=NAVY, elinewidth=2, capsize=4, markersize=7)
for _, r in b.iterrows():
    ax[0].text(r.IC95_sup + 2, r.nacionalidad, f"{r.media:.1f}  [{r.IC95_inf:.1f}; {r.IC95_sup:.1f}]",
               va="center", fontsize=9, color="#333333")
ax[0].set(title="Gasto medio por nacionalidad (IC bootstrap 95 %)", xlabel="gasto promedio (S/)", xlim=(35, 160))
g2 = gh.assign(par=gh.grupo_A + " – " + gh.grupo_B).sort_values("diferencia")
ax[1].errorbar(g2.diferencia, g2.par, xerr=[g2.diferencia - g2.IC95_inf, g2.IC95_sup - g2.diferencia],
               fmt="o", color=AZUL, ecolor="#9cbfe9", elinewidth=3, markersize=5)
ax[1].axvline(0, color=GRIS, lw=1, ls="--")
ax[1].tick_params(axis="y", labelsize=9)
ax[1].set(title="Games-Howell: diferencias de medias (IC 95 % ajustado)", xlabel="diferencia A − B (S/)")
guardar("18_posthoc")


# **Interpretación.** Las **15 comparaciones entre pares** de nacionalidades son significativas con Games-Howell y con Tukey HSD: en todos los pares p < 10⁻¹², que es el límite de precisión numérica del cálculo. La diferencia más pequeña es la de estadounidenses frente a europeos: 10,9 soles (IC 95 %: 6,9 a 15,0).
# - Los intervalos bootstrap de las medias son estrechos (semiancho de 0,7 soles en peruanos a 2,1 soles en estadounidenses) y **no se superponen**: estadounidense (122,3) > europeo (111,4) > asiático (95,3) > otro (79,9) > latinoamericano (65,3) > peruano (45,0).
# - Los seis grupos son **seis niveles de gasto distintos**: no se pueden fusionar categorías sin perder información.

# ## Paso 19. ANOVA de dos vías con interacciones y prueba sobre los residuos
# Se verifica si alguna variable aporta algo **además** de la nacionalidad, ya sea como efecto principal o en
# interacción con ella. Se usa ANOVA tipo II con errores estándar robustos HC3 (por la heterocedasticidad), sobre
# el gasto y sobre log(gasto), que estabiliza la varianza multiplicativa.

# In[34]:


import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

d = df.rename(columns={OBJ: "y"}).copy()
d["log_y"] = np.log(d["y"])
filas = []
for otra in ["sitio_turistico", "temporada", "tipo_transporte", "anio"]:
    for resp in ["y", "log_y"]:
        modelo = smf.ols(f"{resp} ~ C(nacionalidad) * C({otra})", data=d).fit()
        tabla = anova_lm(modelo, typ=2, robust="hc3")
        ss_res = tabla.loc["Residual", "sum_sq"]
        for termino in tabla.index[:-1]:
            ss = tabla.loc[termino, "sum_sq"]
            filas.append([otra, "gasto" if resp == "y" else "log(gasto)", termino.replace("C(", "").replace(")", ""),
                          tabla.loc[termino, "df"], tabla.loc[termino, "F"], tabla.loc[termino, "PR(>F)"],
                          ss / (ss + ss_res)])
anova2 = pd.DataFrame(filas, columns=["factor_2", "respuesta", "termino", "gl", "F", "p", "eta2_parcial"])
anova2["p_Bonferroni"] = (anova2.p * 4).clip(upper=1)     # 4 interacciones evaluadas por respuesta
anova2.to_csv("resultados/anova_dos_vias.csv", index=False)
inter = anova2[anova2.termino.str.contains(":")]
print("Interacciones nacionalidad × factor:")
print(inter.round(4).to_string(index=False))


# In[35]:


# Prueba global sobre los residuos del modelo "solo nacionalidad".
# Se omiten temporada, festividad y tiene_festividad porque el mes las determina por completo (colinealidad).
d["residuo"] = d["y"] - d.groupby("nacionalidad")["y"].transform("mean")
d["residuo_rel"] = d["y"] / d.groupby("nacionalidad")["y"].transform("mean") - 1
formula = ("~ C(sitio_turistico) + C(tipo_transporte) + C(anio) + C(mes_num) + num_visitantes"
           " + temperatura_promedio_c + precipitacion_mm + satisfaccion_1_5")
filas = []
for r in ["residuo", "residuo_rel"]:
    m_ols = smf.ols(r + formula, data=d).fit()
    m_hc3 = smf.ols(r + formula, data=d).fit(cov_type="HC3")
    filas.append([r, m_ols.df_model, m_ols.rsquared, m_ols.fvalue, m_ols.f_pvalue, m_hc3.fvalue, m_hc3.f_pvalue])
resid_test = pd.DataFrame(filas, columns=["residuo", "gl_modelo", "R2", "F", "p", "F_HC3", "p_HC3"])
resid_test.to_csv("resultados/prueba_residuos.csv", index=False)
resid_test.round(4)


# **Interpretación.**
# - **Interacciones:** la única con p nominal < 0,05 es nacionalidad × sitio (p = 0,043 sobre el gasto; 0,035 sobre log(gasto)), con un tamaño de efecto muy pequeño (η² parcial = 0,016). Al corregir por las cuatro interacciones evaluadas (Bonferroni) deja de ser significativa (p = 0,17 y 0,14). Las demás tienen p > 0,12. Además, el modelo que usa la media de cada combinación nacionalidad × sitio **predice peor** en validación cruzada que el de solo nacionalidad (paso 21). Se interpreta como un probable falso positivo por comparaciones múltiples.
# - **Residuos:** las 28 variables restantes explican solo el **0,6 %** de los residuos del modelo "solo nacionalidad" (F = 0,51; p = 0,985; con HC3, p = 0,961). Con los residuos relativos el resultado es el mismo (p = 0,94).
# - **Conclusión:** se confirma estadísticamente que, una vez conocida la nacionalidad, ninguna otra variable aporta información sobre el gasto.

# ## Paso 20. Techo teórico del R² y simulación Monte Carlo
# Si el gasto es la media de su nacionalidad multiplicada por un ruido con coeficiente de variación (CV) constante,
# el R² máximo alcanzable es:
# 
# $$R^2_{\max} = \frac{V_{entre}}{V_{entre} + V_{dentro}}, \qquad V_{entre}=\frac{1}{G}\sum_g(\mu_g-\bar\mu)^2,
# \qquad V_{dentro}=\frac{1}{G}\sum_g (CV\cdot\mu_g)^2$$
# 
# La simulación genera 2 000 datasets con esa estructura (ruido uniforme y normal), los divide 80/20 y mide el R²
# de prueba del modelo ideal (media por nacionalidad).

# In[36]:


g = df.groupby("nacionalidad")[OBJ]
mu_g, sd_g = g.mean(), g.std(ddof=0)
cv_g = sd_g / mu_g
V_entre = ((mu_g - mu_g.mean()) ** 2).mean()
techo_exacto = V_entre / (V_entre + (sd_g ** 2).mean())
cv_comun = np.sqrt((cv_g ** 2).mean())
techo_cv = V_entre / (V_entre + ((cv_comun * mu_g) ** 2).mean())
rel = df[OBJ] / df.nacionalidad.map(mu_g) - 1
print("CV por nacionalidad (%):", (100 * cv_g).round(2).to_dict())
print(f"CV común = {100 * cv_comun:.2f} % | techo con CV común = {techo_cv:.4f} | techo con CV de cada grupo = {techo_exacto:.4f}")
print(f"Forma del ruido relativo: mín {rel.min():+.3f}, máx {rel.max():+.3f}, curtosis {stats.kurtosis(rel):.2f} "
      f"(uniforme = −1,2; normal = 0)")

rng = np.random.default_rng(SEMILLA)
nac_v = df.nacionalidad.values
mu_fila = df.nacionalidad.map(mu_g).values
a = np.sqrt(3) * cv_comun          # semiancho del ruido uniforme con el mismo CV
generadores = {"uniforme": lambda: mu_fila * (1 + rng.uniform(-a, a, len(df))),
               "normal": lambda: mu_fila * (1 + rng.normal(0, cv_comun, len(df)))}
mc = {}
for nombre, gen in generadores.items():
    r2s = []
    for _ in range(2000):
        ys = pd.Series(gen())
        idx = rng.permutation(len(df)); tr, te = idx[:1987], idx[1987:]
        medias = ys.iloc[tr].groupby(nac_v[tr]).mean()
        r2s.append(r2_score(ys.iloc[te], pd.Series(nac_v[te]).map(medias).values))
    mc[nombre] = np.array(r2s)
mc_tabla = pd.DataFrame({k: {"R2_medio": v.mean(), "desv": v.std(), "p2.5": np.percentile(v, 2.5),
                             "p97.5": np.percentile(v, 97.5)} for k, v in mc.items()}).T
r2_cv_omp = cv_res.set_index("modelo").loc["OrthogonalMatchingPursuitCV", "R2_medio"]
r2_test_omp = models.loc["OrthogonalMatchingPursuitCV", "R-Squared"]
mc_tabla["percentil_R2_test_observado"] = [100 * (v < r2_test_omp).mean() for v in mc.values()]
mc_tabla.to_csv("resultados/montecarlo_techo.csv")
techo_tabla = pd.DataFrame({"indicador": ["eta² observado", "techo con CV de cada grupo", "CV común (%)",
                                          "techo con CV común", "R² prueba OMP-CV", "R² CV 5x3 OMP-CV"],
                            "valor": [techo, techo_exacto, 100 * cv_comun, techo_cv, r2_test_omp, r2_cv_omp]})
techo_tabla.to_csv("resultados/techo_teorico.csv", index=False)
print(mc_tabla.round(4))


# In[37]:


fig, ax = plt.subplots(figsize=(9, 4.4))
for i, (k, v) in enumerate(mc.items()):
    ax.hist(v, bins=45, alpha=.55, color=PAL[i], label=f"Monte Carlo, ruido {k}", edgecolor="white")
ax.axvline(techo_cv, color=NAVY, lw=2, label=f"techo analítico = {techo_cv:.3f}")
ax.axvline(r2_test_omp, color=PAL[1], lw=2, ls="--", label=f"R² prueba OMP-CV = {r2_test_omp:.3f}")
ax.axvline(r2_cv_omp, color=PAL[5], lw=2, ls=":", label=f"R² CV 5×3 OMP-CV = {r2_cv_omp:.3f}")
ax.set(title="R² de prueba del modelo ideal en 2 000 simulaciones", xlabel="R²", ylabel="frecuencia")
ax.legend(fontsize=9, loc="upper left")
guardar("20_montecarlo")


# **Interpretación.**
# - El CV del gasto es casi idéntico en las seis nacionalidades (16,6 % a 17,6 %; CV común = 17,2 %). Con la fórmula, el **techo analítico es R²máx = 0,743**, y 0,740 con el CV propio de cada grupo, que coincide con el η² observado.
# - El ruido relativo **no es normal sino uniforme**: va de −31 % a +30 % y su curtosis es −1,19 (la de una distribución uniforme es −1,2). Todo indica que los datos se generaron como media de la nacionalidad × U(0,7; 1,3).
# - **Monte Carlo (2 000 réplicas):** con ruido uniforme, el modelo ideal obtiene R² de prueba = 0,741 en promedio (95 % de las réplicas entre 0,709 y 0,771); con ruido normal, 0,742 (0,703 a 0,779).
# - El R² de prueba de OMP-CV (0,730) cae en el **percentil 22** de esa distribución y el de validación cruzada (0,738) está en el centro. Los modelos lineales **alcanzan el techo**: la diferencia entre 0,730 y 0,743 se debe al azar de la partición, no a un modelo mejorable.

# # BLOQUE 4. Modelos complementarios e incertidumbre

# ## Paso 21. GLM Gamma (enlace log), regresión WLS y modelo con interacción
# El gasto es positivo y su varianza crece con la media, lo que en teoría favorece a un **GLM Gamma con enlace
# log** o a una **regresión ponderada (WLS)** con pesos $1/\sigma^2_g$. Se comparan con OMP-CV en las **mismas 15
# particiones** de la validación cruzada 5×3 del paso 14, guardando el R² de cada partición para las pruebas del paso 22.

# In[38]:


from sklearn.base import BaseEstimator, RegressorMixin, clone
from sklearn.linear_model import GammaRegressor

class WLSNacionalidad(BaseEstimator, RegressorMixin):
    # WLS factible: 1) MCO, 2) varianza residual por nacionalidad, 3) MCO ponderado con pesos 1/varianza
    def __init__(self, cols_nac=None):
        self.cols_nac = cols_nac
    def _grupo(self, X):
        return X[self.cols_nac].astype(str).agg("".join, axis=1).values
    def fit(self, X, y):
        self.esc_ = StandardScaler().fit(X); Z = self.esc_.transform(X)
        res = np.asarray(y) - LinearRegression().fit(Z, y).predict(Z)
        var_g = pd.Series(res).groupby(self._grupo(X)).var()
        pesos = pd.Series(self._grupo(X)).map(1 / var_g).values
        self.modelo_ = LinearRegression().fit(Z, y, sample_weight=pesos)
        return self
    def predict(self, X):
        return self.modelo_.predict(self.esc_.transform(X))

class MediaPorCelda(BaseEstimator, RegressorMixin):
    # Modelo con interacción nacionalidad × sitio: predice la media de cada combinación
    def _clave(self, X):
        return X[[c for c in X.columns if c.startswith(("nacionalidad_", "sitio_"))]].astype(str).agg("".join, axis=1).values
    def fit(self, X, y):
        self.medias_ = pd.Series(np.asarray(y)).groupby(self._clave(X)).mean(); self.global_ = float(np.mean(y))
        return self
    def predict(self, X):
        return pd.Series(self._clave(X)).map(self.medias_).fillna(self.global_).values

modelos_cv = {
    "OMP-CV": (make_pipeline(StandardScaler(), OrthogonalMatchingPursuitCV()), X),
    "LinReg solo nacionalidad": (LinearRegression(), X[cols_nac]),
    "GLM Gamma log, solo nacionalidad": (GammaRegressor(alpha=0, max_iter=1000), X[cols_nac]),
    "GLM Gamma log, 28 variables": (make_pipeline(StandardScaler(), GammaRegressor(alpha=0, max_iter=2000)), X),
    "WLS, 28 variables": (WLSNacionalidad(cols_nac), X),
    "Interacción nacionalidad × sitio": (MediaPorCelda(), X),
    "LassoCV": (make_pipeline(StandardScaler(), LassoCV(random_state=SEMILLA)), X),
    "Ridge": (make_pipeline(StandardScaler(), Ridge()), X),
    "LinearRegression (28 var.)": (make_pipeline(StandardScaler(), LinearRegression()), X),
    "GradientBoosting": (GradientBoostingRegressor(random_state=SEMILLA), X),
    "RandomForest": (RandomForestRegressor(random_state=SEMILLA, n_jobs=-1), X),
    "LGBM": (LGBMRegressor(random_state=SEMILLA, verbose=-1), X),
    "XGB": (XGBRegressor(random_state=SEMILLA, n_jobs=-1), X),
}
particiones = list(RepeatedKFold(n_splits=5, n_repeats=3, random_state=SEMILLA).split(X))   # = paso 14
r2_folds = {}
for nombre, (modelo, Xm) in modelos_cv.items():
    r2_folds[nombre] = [r2_score(y.iloc[te], clone(modelo).fit(Xm.iloc[tr], y.iloc[tr]).predict(Xm.iloc[te]))
                        for tr, te in particiones]
r2_folds = pd.DataFrame(r2_folds)
r2_folds.to_csv("resultados/r2_por_particion.csv", index=False)
cv_comp = pd.DataFrame({"R2_medio": r2_folds.mean(), "R2_desv": r2_folds.std(ddof=1)}).sort_values("R2_medio", ascending=False)
cv_comp.to_csv("resultados/cv_gamma_wls.csv")
cv_comp.round(4)


# **Interpretación.** **Ninguno de los modelos nuevos supera a OMP-CV**, y el resultado era previsible:
# - El **GLM Gamma solo con nacionalidad** obtiene 0,7381 frente a 0,7382: es el mismo modelo. Cuando el único predictor es categórico, MCO, WLS y el GLM Gamma con enlace log estiman lo mismo, la **media de cada grupo**, y por eso sus predicciones puntuales coinciden. Su ventaja frente a la heterocedasticidad está en la inferencia (errores estándar e intervalos), no en la predicción.
# - Con las 28 variables, el GLM Gamma (0,7337) y la WLS (0,7354) quedan por debajo, al igual que Ridge y la regresión lineal: las 23 variables sin información añaden ruido a la estimación.
# - El modelo con **interacción nacionalidad × sitio** (0,7344) también empeora, lo que confirma lo dicho en el paso 19.
# - Resultado honesto: modelar la varianza no mejora la predicción en este dataset.

# ## Paso 22. ¿Las diferencias entre modelos son significativas?
# Las 15 particiones comparten datos, así que una t pareada común subestima la varianza. Se usa la **t corregida
# de Nadeau y Bengio**: $t = \bar d \,/\, \sqrt{(1/J + n_{prueba}/n_{entren})\,s_d^2}$ con $J-1=14$ gl. Como
# contraste global se aplica **Friedman** y la diferencia crítica de **Nemenyi** sobre los rangos.

# In[39]:


J = len(particiones)
razon = len(particiones[0][1]) / len(particiones[0][0])        # n_prueba / n_entrenamiento = 0,25
filas = []
for nombre in r2_folds.columns.drop("OMP-CV"):
    dif = r2_folds["OMP-CV"] - r2_folds[nombre]
    s2 = dif.var(ddof=1)
    t_nb = dif.mean() / np.sqrt((1 / J + razon) * s2) if s2 > 0 else 0.0
    p_nb = 2 * stats.t.sf(abs(t_nb), J - 1) if s2 > 0 else 1.0
    t_ing = dif.mean() / np.sqrt(s2 / J) if s2 > 0 else 0.0
    p_ing = 2 * stats.t.sf(abs(t_ing), J - 1) if s2 > 0 else 1.0
    filas.append([nombre, dif.mean(), t_nb, p_nb, t_ing, p_ing])
nb = pd.DataFrame(filas, columns=["modelo", "dif_R2_OMP_menos_modelo", "t_NB", "p_NB", "t_ingenua", "p_ingenua"])
# Ajuste de Holm por comparaciones múltiples (12 pruebas contra OMP-CV)
orden = np.argsort(nb.p_NB.values); m_ = len(nb)
holm = np.minimum(1, np.maximum.accumulate((m_ - np.arange(m_)) * nb.p_NB.values[orden]))
nb["p_NB_Holm"] = np.empty(m_); nb.loc[nb.index[orden], "p_NB_Holm"] = holm
nb.to_csv("resultados/nadeau_bengio.csv", index=False)

rangos = r2_folds.rank(axis=1, ascending=False)
fr = stats.friedmanchisquare(*[r2_folds[c] for c in r2_folds.columns])
k, N = r2_folds.shape[1], r2_folds.shape[0]
CD = stats.studentized_range.ppf(0.95, k, 1e6) / np.sqrt(2) * np.sqrt(k * (k + 1) / (6 * N))
rango_medio = rangos.mean().sort_values()
pd.DataFrame({"rango_medio": rango_medio}).assign(CD_Nemenyi=CD).to_csv("resultados/friedman_nemenyi.csv")
print(f"Friedman: chi2 = {fr.statistic:.2f}, p = {fr.pvalue:.2e} | Diferencia crítica de Nemenyi = {CD:.2f}")
nb.round(4)


# In[40]:


fig, ax = plt.subplots(figsize=(10, 5))
rm = rango_medio.iloc[::-1]
colores = [AZUL if v - rango_medio.min() <= CD else GRIS for v in rm.values]
ax.barh(rm.index, rm.values, color=colores, height=.6)
ax.axvline(rango_medio.min() + CD, color=PAL[1], ls="--", lw=1.5,
           label=f"mejor rango + CD de Nemenyi ({rango_medio.min():.1f} + {CD:.1f})")
ax.tick_params(axis="y", labelsize=10)
ax.set(title="Rango medio en las 15 particiones (1 = mejor)", xlabel="rango medio")
ax.legend(fontsize=9, loc="upper center", bbox_to_anchor=(.5, -.12))
guardar("22_friedman_nemenyi")


# **Interpretación.**
# - **Friedman** rechaza que todos los modelos sean equivalentes (χ² = 159,9; p = 5·10⁻²⁸). Con la diferencia crítica de Nemenyi (CD = 4,71), forman el grupo líder, sin diferencias significativas entre sí: GLM Gamma solo nacionalidad, OMP-CV, regresión solo nacionalidad, LassoCV, WLS y el modelo con interacción.
# - **t corregida de Nadeau-Bengio frente a OMP-CV:** no hay diferencia con la regresión solo nacionalidad (p = 0,84), el GLM Gamma solo nacionalidad (p = 0,66), LassoCV (p = 0,083) ni el modelo con interacción (p = 0,055). Ridge y la regresión lineal con 28 variables sí son **significativamente peores** (p = 0,0045; p de Holm = 0,036), igual que Gradient Boosting (p = 0,0018) y, con más razón, Random Forest, LightGBM y XGBoost (p < 0,001).
# - **Matiz importante:** la desventaja de los lineales con 28 variables es real pero minúscula: 0,0045 de R², unos 0,14 soles de RMSE. Es estadísticamente detectable y prácticamente irrelevante.
# - **Por qué hace falta la corrección:** la t pareada ingenua (columna `t_ingenua`) declararía significativas casi todas las diferencias, incluida la de LassoCV (p = 0,001), porque ignora que las particiones comparten datos.

# ## Paso 23. Métricas por nacionalidad e intervalos de predicción
# Se evalúa el modelo final por grupo (RMSE, MAE, MAPE) y se construyen intervalos de predicción al 95 % con tres
# métodos, verificando su **cobertura empírica** en el conjunto de prueba (lo ideal es ≈ 95 %).

# In[41]:


nac_te = Xr_te["nacionalidad"]
res_te = y_test - pred
met_nac = pd.DataFrame({
    "n_prueba": res_te.groupby(nac_te).size(),
    "media_real": y_test.groupby(nac_te).mean(),
    "RMSE": res_te.groupby(nac_te).apply(lambda r: np.sqrt((r ** 2).mean())),
    "MAE": res_te.abs().groupby(nac_te).mean(),
    "MAPE_%": (100 * res_te.abs() / y_test).groupby(nac_te).mean(),
}).reindex(nac_orden)
met_nac.loc["Global"] = [len(res_te), y_test.mean(), np.sqrt((res_te ** 2).mean()), res_te.abs().mean(),
                         (100 * res_te.abs() / y_test).mean()]
met_nac.to_csv("resultados/metricas_por_nacionalidad.csv")

# Parámetros de los intervalos, estimados SOLO con el conjunto de entrenamiento
nac_tr = Xr_tr["nacionalidad"]
mu_tr = y_train.groupby(nac_tr).mean()
rel_tr = y_train / nac_tr.map(mu_tr) - 1
cv_global = rel_tr.std()
cv_grupo = y_train.groupby(nac_tr).std() / mu_tr
q_inf, q_sup = rel_tr.quantile([0.025, 0.975])
metodos = {
    "A: ±1,96·CV global·μ (normal)": (pred * (1 - 1.96 * cv_global), pred * (1 + 1.96 * cv_global)),
    "B: ±1,96·CV del grupo·μ (normal)": (pred * (1 - 1.96 * nac_te.map(cv_grupo).values),
                                         pred * (1 + 1.96 * nac_te.map(cv_grupo).values)),
    "C: cuantiles empíricos 2,5–97,5 %": (pred * (1 + q_inf), pred * (1 + q_sup)),
}
filas = []
for nombre, (lo, hi) in metodos.items():
    dentro = pd.Series((y_test.values >= lo) & (y_test.values <= hi), index=y_test.index)
    ancho = pd.Series(hi - lo, index=y_test.index)
    fila = {"metodo": nombre, "cobertura_global_%": 100 * dentro.mean(), "ancho_medio_S/": ancho.mean()}
    fila.update({f"cob_{k}_%": 100 * dentro[nac_te == k].mean() for k in nac_orden})
    filas.append(fila)
cobertura = pd.DataFrame(filas)
cobertura.to_csv("resultados/cobertura_intervalos.csv", index=False)
print(f"CV global (entrenamiento) = {100 * cv_global:.2f} % | cuantiles relativos: {q_inf:+.4f} / {q_sup:+.4f}")
display(met_nac.round(2))
cobertura.round(1)


# In[42]:


fig, ax = plt.subplots(figsize=(11, 4.8))
for i, k in enumerate(nac_orden):
    m = (nac_te == k).values
    xs = i + rng.uniform(-.25, .25, m.sum())
    ax.scatter(xs, y_test.values[m], s=10, color=PAL[i], alpha=.6, zorder=3)
    mu_k = mu_tr[k]
    for off, (lo, hi), col, lab in [(-.33, (mu_k * (1 - 1.96 * cv_global), mu_k * (1 + 1.96 * cv_global)), GRIS, "A: normal ±1,96·CV"),
                                    (.33, (mu_k * (1 + q_inf), mu_k * (1 + q_sup)), NAVY, "C: cuantiles empíricos")]:
        ax.plot([i + off, i + off], [lo, hi], color=col, lw=4, solid_capstyle="butt", label=lab if i == 0 else None)
    ax.plot([i - .3, i + .3], [mu_k, mu_k], color="black", lw=1.5)
ax.set_xticks(range(len(nac_orden))); ax.set_xticklabels(nac_orden, fontsize=10)
ax.set(title="Intervalos de predicción al 95 % y gasto real en prueba", ylabel="gasto (S/)")
ax.legend(fontsize=9, loc="upper right")
guardar("23_intervalos")


# **Interpretación.**
# - **Métricas por nacionalidad:** el error absoluto crece con el nivel de gasto (RMSE de 7,3 soles en peruanos y 22,0 en estadounidenses), pero el **error relativo es parecido** (MAPE entre 12,8 % y 17,8 %; global 15,7 %). Es lo esperado con ruido multiplicativo: el modelo es igual de preciso, en proporción, para todos los grupos.
# - **Intervalos de predicción:**
#   - Los métodos A y B (±1,96 × 17 % × media, con supuesto normal) tienen una cobertura del **100 %** en todos los grupos: son **demasiado anchos** (59 soles en promedio). Como el ruido es uniforme y acotado en ±30 %, el supuesto normal exagera las colas: 1,96 × 17,2 % = 33,7 % es más que el máximo real.
#   - El método C (cuantiles empíricos del ruido relativo de entrenamiento: −28,4 % y +28,3 %) logra una cobertura de **94,4 %**, muy cerca del 95 % nominal (91,6 % a 98,8 % según el grupo), con intervalos **16 % más estrechos** (49,8 soles).
# - **Recomendación:** usar los intervalos empíricos (método C). Es la opción que usa la app.

# # BLOQUE 5. Valor aplicado

# ## Paso 24. Ingreso estimado por nacionalidad
# Ingreso estimado de cada registro = número de visitantes × gasto promedio. Se suma por nacionalidad, sitio y año.

# In[43]:


df["ingreso"] = df["num_visitantes"] * df[OBJ]
ing = df.groupby("nacionalidad").agg(visitantes=("num_visitantes", "sum"), ingreso_S=("ingreso", "sum"))
ing["gasto_ponderado_S"] = ing.ingreso_S / ing.visitantes
ing["pct_visitantes"] = 100 * ing.visitantes / ing.visitantes.sum()
ing["pct_ingreso"] = 100 * ing.ingreso_S / ing.ingreso_S.sum()
ing = ing.sort_values("ingreso_S", ascending=False)
ing.to_csv("resultados/ingreso_por_nacionalidad.csv")
ing_sitio = df.groupby("sitio_turistico").ingreso.sum().sort_values(ascending=False)
ing_sitio = pd.DataFrame({"ingreso_S": ing_sitio, "pct": 100 * ing_sitio / ing_sitio.sum()})
ing_sitio.to_csv("resultados/ingreso_por_sitio.csv")
ing_anio = df.groupby("anio").agg(visitantes=("num_visitantes", "sum"), ingreso_S=("ingreso", "sum"))
ing_anio.to_csv("resultados/ingreso_por_anio.csv")
print(f"Ingreso total estimado 2019–2024: S/ {ing.ingreso_S.sum():,.0f}")
display(ing_sitio.round(1)); display(ing_anio.round(0))
ing.round(2)


# In[44]:


fig, ax = plt.subplots(1, 2, figsize=(14, 4.8), gridspec_kw={"width_ratios": [1.3, 1]})
x = np.arange(len(ing)); w = .38
ax[0].bar(x - w / 2, ing.pct_visitantes, w, color=GRIS, label="% de visitantes")
ax[0].bar(x + w / 2, ing.pct_ingreso, w, color=AZUL, label="% del ingreso")
for i, (pv, pi) in enumerate(zip(ing.pct_visitantes, ing.pct_ingreso)):
    ax[0].text(i - w / 2, pv + .6, f"{pv:.1f}", ha="center", fontsize=9, color="#52514e")
    ax[0].text(i + w / 2, pi + .6, f"{pi:.1f}", ha="center", fontsize=9, color=NAVY)
ax[0].set_xticks(x); ax[0].set_xticklabels(ing.index, fontsize=10)
ax[0].set(title="Aporte de cada nacionalidad a visitantes e ingreso", ylabel="%")
ax[0].legend(fontsize=9)
acum = ing.pct_ingreso.cumsum()
ax[1].barh(ing.index[::-1], ing.ingreso_S[::-1] / 1e6, color=AZUL, height=.6)
for i, (v, c) in enumerate(zip(ing.ingreso_S[::-1] / 1e6, acum[::-1])):
    ax[1].text(v + .1, i, f"S/ {v:.1f} M  (acum. {c:.0f} %)", va="center", fontsize=9)
ax[1].set(title="Ingreso estimado 2019–2024", xlabel="millones de soles", xlim=(0, ing.ingreso_S.max() / 1e6 * 1.6))
guardar("24_ingreso")


# **Interpretación.**
# - El ingreso estimado 2019–2024 asciende a **S/ 29,9 millones**.
# - **Europeos y estadounidenses** generan el **58 % del ingreso** con solo el 41 % de los visitantes. Su gasto ponderado es de S/ 110,8 y S/ 124,1 por turista.
# - **Peruanos:** son el grupo más numeroso (35,3 % de los visitantes), pero aportan el 19,4 % del ingreso, porque gastan unos S/ 45 por persona.
# - **Por sitio:** las **Islas Uros** (48,1 %) y **Taquile** (23,1 %) concentran el 71 % del ingreso, porque reciben más visitantes. Aramu Muru aporta solo el 2,3 %.
# - **Por año:** en 2020 el ingreso cayó 85,5 % respecto a 2019 (por menos visitantes, no por menor gasto). En 2023 se recuperó (S/ 7,2 millones) y superó a 2019.
# - **Advertencia:** es una aproximación (visitantes × gasto promedio) sobre un dataset que parece sintético; sirve para ilustrar el uso del modelo, no como cifra oficial.

# ## Paso 25. Guardar el modelo final (joblib) para la app de Streamlit
# Para la app se entrena el modelo equivalente más simple, **regresión lineal con la nacionalidad** (en el paso 21
# iguala a OMP-CV), con **todos** los datos. Se guardan también los cuantiles empíricos de los intervalos.

# In[45]:


import joblib
from datetime import date

modelo_app = make_pipeline(
    ColumnTransformer([("nac", OneHotEncoder(drop="first", handle_unknown="error"), ["nacionalidad"])]),
    LinearRegression())
modelo_app.fit(df[["nacionalidad"]], df[OBJ])
rel_todo = df[OBJ] / df.groupby("nacionalidad")[OBJ].transform("mean") - 1
paquete = {
    "modelo": modelo_app,
    "nacionalidades": sorted(df.nacionalidad.unique()),
    "q_inf": float(rel_todo.quantile(0.025)), "q_sup": float(rel_todo.quantile(0.975)),
    "cv_global": float(rel_todo.std()),
    "r2_cv": float(r2_folds["LinReg solo nacionalidad"].mean()),
    "fecha": str(date.today()), "n_registros": len(df),
}
joblib.dump(paquete, "modelo_gasto_turista.joblib")

# Prueba de carga y predicción
p = joblib.load("modelo_gasto_turista.joblib")
prueba = pd.DataFrame({"nacionalidad": p["nacionalidades"]})
prueba["gasto_esperado"] = p["modelo"].predict(prueba)
prueba["IP95_inf"] = prueba.gasto_esperado * (1 + p["q_inf"])
prueba["IP95_sup"] = prueba.gasto_esperado * (1 + p["q_sup"])
prueba.to_csv("resultados/predicciones_app.csv", index=False)
print("Modelo guardado en modelo_gasto_turista.joblib. Para la app: streamlit run app_streamlit.py")
prueba.round(2)


# ## Paso 26. Reproducibilidad: versiones de librerías y semillas

# In[46]:


import sys, platform, importlib.metadata as md_
paquetes = ["pandas", "numpy", "scipy", "scikit-learn", "lazypredict", "lightgbm", "xgboost",
            "statsmodels", "matplotlib", "seaborn", "joblib", "streamlit"]
versiones = [["python", platform.python_version()]]
for pkg in paquetes:
    try:
        versiones.append([pkg, md_.version(pkg)])
    except md_.PackageNotFoundError:
        versiones.append([pkg, "no instalado"])
versiones = pd.DataFrame(versiones, columns=["libreria", "version"])
versiones.to_csv("resultados/versiones_librerias.csv", index=False)
with open("requirements_entorno.txt", "w") as f:
    f.writelines(f"{r.libreria}=={r.version}\n" for r in versiones.itertuples() if r.libreria != "python"
                 and r.version != "no instalado")
semillas = pd.DataFrame({"uso": ["train_test_split 80/20", "RepeatedKFold 5x3", "modelos con azar (RF, GB, XGB, LGBM, MLP, Lasso)",
                                 "bootstrap de medias (10 000)", "Monte Carlo (2 000 x 2)"],
                         "semilla": [SEMILLA] * 5})
semillas.to_csv("resultados/semillas.csv", index=False)
display(semillas)
versiones


# # Conclusiones generales
# 
# 1. **El R² ≈ 0 inicial fue un error de preprocesamiento.** `pd.get_dummies()` generó columnas `bool` que la versión de LazyPredict descartó en silencio; los modelos entrenaron con 7 variables y sin la nacionalidad. Hay dos formas de corregirlo: `dtype=int` o pasar el texto sin codificar. Ambas dan el mismo ganador, pero cambian el orden de los modelos sensibles a la escala. La función `verificar_X()` evita que el error se repita.
# 2. **El EDA anticipó el resultado:** la nacionalidad explica el 74 % de la varianza del gasto. Las 15 diferencias entre pares de nacionalidades son significativas (Games-Howell), y ni las interacciones ni las demás variables aportan información (ANOVA de dos vías y prueba sobre los residuos: p = 0,98).
# 3. **El techo de predicción está demostrado:** con un CV de 17,2 % el R² máximo es 0,743, y la simulación Monte Carlo da 0,741 (0,709 a 0,771). El ruido es uniforme multiplicativo (±30 %).
# 4. **LazyPredict (corregido) evaluó 42 modelos en ~6 s.** Ganan los modelos lineales (OMP-CV: R² = 0,730, RMSE = 16,3), que alcanzan el techo. Los resultados son robustos en validación cruzada (0,738 ± 0,008), con hiperparámetros ajustados (Gradient Boosting: 0,725) y en la partición temporal 2024 (0,710).
# 5. **Las diferencias entre modelos se probaron estadísticamente** (Nadeau-Bengio y Friedman-Nemenyi). Los modelos parsimoniosos (solo nacionalidad) son significativamente mejores que los ensambles de árboles y, por un margen mínimo (0,0045 de R²), que los lineales con 28 variables. El GLM Gamma y la WLS no mejoran la predicción.
# 6. **Modelo recomendado:** regresión lineal con la nacionalidad (equivalente a OMP-CV), con intervalos de predicción empíricos (cobertura de 94,4 %) y un error relativo de alrededor del 16 % en todos los grupos. El modelo está guardado y disponible en una app de Streamlit.
# 7. **Aplicación:** europeos y estadounidenses aportan el 58 % del ingreso estimado con el 41 % de los visitantes, y las islas (Uros y Taquile) concentran el 71 %.
# 
# **Lección para usar LazyPredict:** es una herramienta de *screening* rápido, pero no reemplaza el EDA. Hay que revisar cuántas variables usan realmente los modelos (el log de LightGBM lo delató), validar con más de una partición, probar si las diferencias son significativas y comparar contra un modelo de referencia y contra el techo teórico.
